// Node.js server with MySQL connection
const http = require("http")
const mysql = require("mysql2/promise")
const { parse } = require("url")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")

// Database connection configuration
const dbConfig = {
  host: "localhost",
  user: "root",
  password: "sahilshah35",
  database: "Spacy",
}
// Create a connection pool
const pool = mysql.createPool(dbConfig)

// JWT secret key
const JWT_SECRET = "1234"

// Helper to send JSON response
const sendJSON = (res, data, statusCode = 200) => {
  res.writeHead(statusCode, { "Content-Type": "application/json" })
  res.end(JSON.stringify(data))
}

// Helper to read request body
const readBody = (req) => {
  return new Promise((resolve, reject) => {
    let body = ""
    req.on("data", (chunk) => {
      body += chunk.toString()
    })
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {})
      } catch (error) {
        reject(error)
      }
    })
    req.on("error", reject)
  })
}

// Authentication middleware
const authenticate = async (req, res) => {
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    sendJSON(res, { error: "Unauthorized" }, 401)
    return null
  }

  const token = authHeader.split(" ")[1]
  try {
    const decoded = jwt.verify(token, JWT_SECRET)
    // Get user from database to ensure they still exist and have proper permissions
    const [users] = await pool.query(
      `SELECT u.user_id, u.name, u.email, r.role_name as role 
       FROM users u 
       JOIN user_roles r ON u.role_id = r.role_id 
       WHERE u.user_id = ?`,
      [decoded.userId],
    )

    if (users.length === 0) {
      sendJSON(res, { error: "User not found" }, 401)
      return null
    }

    return users[0]
  } catch (error) {
    sendJSON(res, { error: "Invalid token" }, 401)
    return null
  }
}

// Create HTTP server
const server = http.createServer(async (req, res) => {
  // Enable CORS
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")

  // Handle preflight requests
  if (req.method === "OPTIONS") {
    res.writeHead(204)
    res.end()
    return
  }

  // Parse URL
  const parsedUrl = parse(req.url, true)
  const path = parsedUrl.pathname
  const query = parsedUrl.query

  try {
    // API routes
    if (path.startsWith("/api")) {
      // Authentication routes
      if (path === "/api/auth/login" && req.method === "POST") {
        const data = await readBody(req)
        const { email, password } = data

        if (!email || !password) {
          sendJSON(res, { error: "Email and password are required" }, 400)
          return
        }

        try {
          // Get user from database
          const [users] = await pool.query(
            `SELECT u.user_id, u.name, u.email, u.password_hash, r.role_name as role 
             FROM users u 
             JOIN user_roles r ON u.role_id = r.role_id 
             WHERE u.email = ?`,
            [email],
          )

          if (users.length === 0) {
            sendJSON(res, { error: "Invalid credentials" }, 401)
            return
          }

          const user = users[0]

          // Compare password
          const isMatch = await bcrypt.compare(password, user.password_hash)
          if (!isMatch) {
            sendJSON(res, { error: "Invalid credentials" }, 401)
            return
          }

          // Generate JWT token
          const token = jwt.sign({ userId: user.user_id, role: user.role }, JWT_SECRET, { expiresIn: "1d" })

          // Return user info and token
          sendJSON(res, {
            token,
            user: {
              id: user.user_id,
              name: user.name,
              email: user.email,
              role: user.role,
            },
          })
        } catch (error) {
          console.error("Login error:", error)
          sendJSON(res, { error: "Server error" }, 500)
        }
        return
      }

      // Registration route
      if (path === "/api/auth/register" && req.method === "POST") {
        const data = await readBody(req)
        const { name, email, password } = data

        if (!name || !email || !password) {
          sendJSON(res, { error: "Name, email and password are required" }, 400)
          return
        }

        try {
          // Check if user already exists
          const [existingUsers] = await pool.query("SELECT * FROM users WHERE email = ?", [email])

          if (existingUsers.length > 0) {
            sendJSON(res, { error: "User with this email already exists" }, 400)
            return
          }

          // Get the role_id for 'astronaut' (default role for new users)
          const [roles] = await pool.query("SELECT role_id FROM user_roles WHERE role_name = ?", ["astronaut"])

          if (roles.length === 0) {
            sendJSON(res, { error: "Role not found" }, 500)
            return
          }

          const roleId = roles[0].role_id

          // Hash the password
          const passwordHash = await bcrypt.hash(password, 10)

          // Insert the new user
          const [result] = await pool.query(
            "INSERT INTO users (name, email, password_hash, role_id) VALUES (?, ?, ?, ?)",
            [name, email, passwordHash, roleId],
          )

          sendJSON(
            res,
            {
              success: true,
              message: "User registered successfully",
              userId: result.insertId,
            },
            201,
          )
        } catch (error) {
          console.error("Registration error:", error)
          sendJSON(res, { error: "Server error" }, 500)
        }
        return
      }

      // Protected routes - require authentication
      if (path !== "/api/auth/login" && path !== "/api/auth/register") {
        const user = await authenticate(req, res)
        if (!user) return

        // Users routes
        if (path === "/api/users" && req.method === "GET") {
          // Only admin can access all users
          if (user.role !== "admin") {
            sendJSON(res, { error: "Forbidden" }, 403)
            return
          }

          try {
            const [users] = await pool.query(
              `SELECT u.user_id, u.name, u.email, r.role_name as role, u.created_at 
               FROM users u 
               JOIN user_roles r ON u.role_id = r.role_id`,
            )

            sendJSON(res, users)
          } catch (error) {
            console.error("Get users error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Get current user
        if (path === "/api/users/me" && req.method === "GET") {
          sendJSON(res, user)
          return
        }

        // Storage units routes
        if (path === "/api/storage-units" && req.method === "GET") {
          try {
            const [units] = await pool.query(
              `SELECT u.unit_id, u.unit_name, l.location_name, u.max_capacity, u.current_load 
               FROM storage_units u 
               JOIN storage_locations l ON u.location_id = l.location_id`,
            )

            sendJSON(res, units)
          } catch (error) {
            console.error("Get storage units error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Cargo items routes
        if (path === "/api/cargo-items" && req.method === "GET") {
          try {
            const [items] = await pool.query(
              `SELECT i.item_id, i.item_name, c.category_name, i.quantity, i.unit_weight, 
                      i.expiration_date, i.stored_in_unit, u.unit_name, i.added_at 
               FROM cargo_items i 
               JOIN cargo_categories c ON i.category_id = c.category_id 
               JOIN storage_units u ON i.stored_in_unit = u.unit_id`,
            )

            sendJSON(res, items)
          } catch (error) {
            console.error("Get cargo items error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Add cargo item
        if (path === "/api/cargo-items" && req.method === "POST") {
          const data = await readBody(req)
          const { item_name, category_id, quantity, unit_weight, expiration_date, stored_in_unit } = data

          if (!item_name || !category_id || !quantity || !unit_weight || !stored_in_unit) {
            sendJSON(res, { error: "Missing required fields" }, 400)
            return
          }

          try {
            // Start a transaction
            const connection = await pool.getConnection()
            await connection.beginTransaction()

            try {
              // Insert cargo item
              const [result] = await connection.query(
                `INSERT INTO cargo_items 
                 (item_name, category_id, quantity, unit_weight, expiration_date, stored_in_unit, added_by) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [item_name, category_id, quantity, unit_weight, expiration_date || null, stored_in_unit, user.user_id],
              )

              // Update storage unit current load
              await connection.query(`UPDATE storage_units SET current_load = current_load + ? WHERE unit_id = ?`, [
                quantity,
                stored_in_unit,
              ])

              // Record movement
              await connection.query(
                `INSERT INTO cargo_movements 
                 (item_id, action, quantity, moved_by, to_unit) 
                 VALUES (?, 'stored', ?, ?, ?)`,
                [result.insertId, quantity, user.user_id, stored_in_unit],
              )

              await connection.commit()

              // Get the inserted item with category name
              const [items] = await pool.query(
                `SELECT i.item_id, i.item_name, c.category_name, i.quantity, i.unit_weight, 
                        i.expiration_date, i.stored_in_unit, u.unit_name, i.added_at 
                 FROM cargo_items i 
                 JOIN cargo_categories c ON i.category_id = c.category_id 
                 JOIN storage_units u ON i.stored_in_unit = u.unit_id 
                 WHERE i.item_id = ?`,
                [result.insertId],
              )

              sendJSON(res, items[0], 201)
            } catch (error) {
              await connection.rollback()
              throw error
            } finally {
              connection.release()
            }
          } catch (error) {
            console.error("Add cargo item error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Move cargo item
        if (path.match(/^\/api\/cargo-items\/\d+\/move$/) && req.method === "POST") {
          const itemId = Number.parseInt(path.split("/")[3])
          const data = await readBody(req)
          const { to_unit, quantity } = data

          if (!to_unit || !quantity) {
            sendJSON(res, { error: "Missing required fields" }, 400)
            return
          }

          try {
            // Start a transaction
            const connection = await pool.getConnection()
            await connection.beginTransaction()

            try {
              // Get current item info
              const [items] = await connection.query(`SELECT * FROM cargo_items WHERE item_id = ?`, [itemId])

              if (items.length === 0) {
                await connection.rollback()
                sendJSON(res, { error: "Item not found" }, 404)
                return
              }

              const item = items[0]
              const fromUnit = item.stored_in_unit

              // Check if quantity is valid
              if (quantity > item.quantity) {
                await connection.rollback()
                sendJSON(res, { error: "Quantity exceeds available amount" }, 400)
                return
              }

              // Update item quantity or move completely
              if (quantity === item.quantity) {
                // Move entire item
                await connection.query(`UPDATE cargo_items SET stored_in_unit = ? WHERE item_id = ?`, [to_unit, itemId])
              } else {
                // Reduce quantity from original item
                await connection.query(`UPDATE cargo_items SET quantity = quantity - ? WHERE item_id = ?`, [
                  quantity,
                  itemId,
                ])

                // Create new item in destination
                await connection.query(
                  `INSERT INTO cargo_items 
                   (item_name, category_id, quantity, unit_weight, expiration_date, stored_in_unit, added_by) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)`,
                  [
                    item.item_name,
                    item.category_id,
                    quantity,
                    item.unit_weight,
                    item.expiration_date,
                    to_unit,
                    user.user_id,
                  ],
                )
              }

              // Update storage units current load
              await connection.query(`UPDATE storage_units SET current_load = current_load - ? WHERE unit_id = ?`, [
                quantity,
                fromUnit,
              ])

              await connection.query(`UPDATE storage_units SET current_load = current_load + ? WHERE unit_id = ?`, [
                quantity,
                to_unit,
              ])

              // Record movement
              await connection.query(
                `INSERT INTO cargo_movements 
                 (item_id, action, quantity, moved_by, from_unit, to_unit) 
                 VALUES (?, 'moved', ?, ?, ?, ?)`,
                [itemId, quantity, user.user_id, fromUnit, to_unit],
              )

              await connection.commit()

              sendJSON(res, { success: true, message: "Item moved successfully" })
            } catch (error) {
              await connection.rollback()
              throw error
            } finally {
              connection.release()
            }
          } catch (error) {
            console.error("Move cargo item error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Waste management routes
        if (path === "/api/waste-management" && req.method === "GET") {
          try {
            const [waste] = await pool.query(
              `SELECT w.waste_id, i.item_name, c.category_name, w.quantity, i.unit_weight, 
                      i.expiration_date, wr.reason_description, w.status, w.recorded_at 
               FROM waste_management w 
               JOIN cargo_items i ON w.item_id = i.item_id 
               JOIN cargo_categories c ON i.category_id = c.category_id 
               JOIN waste_reasons wr ON w.reason_id = wr.reason_id`,
            )

            sendJSON(res, waste)
          } catch (error) {
            console.error("Get waste management error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Add waste item
        if (path === "/api/waste-management" && req.method === "POST") {
          const data = await readBody(req)
          const { item_id, quantity, reason_id } = data

          if (!item_id || !quantity || !reason_id) {
            sendJSON(res, { error: "Missing required fields" }, 400)
            return
          }

          try {
            // Start a transaction
            const connection = await pool.getConnection()
            await connection.beginTransaction()

            try {
              // Get current item info
              const [items] = await connection.query(`SELECT * FROM cargo_items WHERE item_id = ?`, [item_id])

              if (items.length === 0) {
                await connection.rollback()
                sendJSON(res, { error: "Item not found" }, 404)
                return
              }

              const item = items[0]

              // Check if quantity is valid
              if (quantity > item.quantity) {
                await connection.rollback()
                sendJSON(res, { error: "Quantity exceeds available amount" }, 400)
                return
              }

              // Add to waste management
              const [result] = await connection.query(
                `INSERT INTO waste_management 
                 (item_id, quantity, reason_id, recorded_by) 
                 VALUES (?, ?, ?, ?)`,
                [item_id, quantity, reason_id, user.user_id],
              )

              // Update item quantity
              await connection.query(`UPDATE cargo_items SET quantity = quantity - ? WHERE item_id = ?`, [
                quantity,
                item_id,
              ])

              // Update storage unit current load
              await connection.query(`UPDATE storage_units SET current_load = current_load - ? WHERE unit_id = ?`, [
                quantity,
                item.stored_in_unit,
              ])

              // Record movement
              await connection.query(
                `INSERT INTO cargo_movements 
                 (item_id, action, quantity, moved_by, from_unit) 
                 VALUES (?, 'disposed', ?, ?, ?)`,
                [item_id, quantity, user.user_id, item.stored_in_unit],
              )

              await connection.commit()

              // Get the inserted waste item
              const [waste] = await pool.query(
                `SELECT w.waste_id, i.item_name, c.category_name, w.quantity, i.unit_weight, 
                        i.expiration_date, wr.reason_description, w.status, w.recorded_at 
                 FROM waste_management w 
                 JOIN cargo_items i ON w.item_id = i.item_id 
                 JOIN cargo_categories c ON i.category_id = c.category_id 
                 JOIN waste_reasons wr ON w.reason_id = wr.reason_id 
                 WHERE w.waste_id = ?`,
                [result.insertId],
              )

              sendJSON(res, waste[0], 201)
            } catch (error) {
              await connection.rollback()
              throw error
            } finally {
              connection.release()
            }
          } catch (error) {
            console.error("Add waste item error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Alerts routes
        if (path === "/api/alerts" && req.method === "GET") {
          try {
            const [alerts] = await pool.query(
              `SELECT a.alert_id, a.message, at.type_name, a.status, a.created_at 
               FROM alerts a 
               JOIN alert_types at ON a.alert_type_id = at.alert_type_id 
               ORDER BY a.created_at DESC`,
            )

            sendJSON(res, alerts)
          } catch (error) {
            console.error("Get alerts error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Get cargo categories
        if (path === "/api/cargo-categories" && req.method === "GET") {
          try {
            const [categories] = await pool.query(`SELECT * FROM cargo_categories`)

            sendJSON(res, categories)
          } catch (error) {
            console.error("Get cargo categories error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Get waste reasons
        if (path === "/api/waste-reasons" && req.method === "GET") {
          try {
            const [reasons] = await pool.query(`SELECT * FROM waste_reasons`)

            sendJSON(res, reasons)
          } catch (error) {
            console.error("Get waste reasons error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }

        // Get storage utilization
        if (path === "/api/utilization" && req.method === "GET") {
          try {
            const [units] = await pool.query(
              `SELECT unit_name as name, current_load as current, max_capacity as capacity 
               FROM storage_units`,
            )

            sendJSON(res, units)
          } catch (error) {
            console.error("Get utilization error:", error)
            sendJSON(res, { error: "Server error" }, 500)
          }
          return
        }
      }

      // Not found
      sendJSON(res, { error: "Not found" }, 404)
    } else {
      // Serve static files (in a real app)
      res.writeHead(404)
      res.end("Not found")
    }
  } catch (error) {
    console.error("Server error:", error)
    sendJSON(res, { error: "Server error" }, 500)
  }
})

// Initialize database with default data if needed
const initializeDatabase = async () => {
  try {
    const connection = await pool.getConnection()

    // Check if user_roles table is empty
    const [roles] = await connection.query("SELECT * FROM user_roles")
    if (roles.length === 0) {
      // Insert default roles
      await connection.query("INSERT INTO user_roles (role_name) VALUES ('admin'), ('astronaut'), ('staff')")
      console.log("Default roles created")

      // Insert default admin user
      const passwordHash = await bcrypt.hash("admin123", 10)
      await connection.query("INSERT INTO users (name, email, password_hash, role_id) VALUES (?, ?, ?, ?)", [
        "Admin User",
        "admin@example.com",
        passwordHash,
        1,
      ])
      console.log("Default admin user created")

      // Insert default storage locations
      await connection.query(
        "INSERT INTO storage_locations (location_name) VALUES ('Forward'), ('Mid-deck'), ('Aft'), ('Lab Module'), ('Galley')",
      )
      console.log("Default storage locations created")

      // Insert default storage units
      await connection.query(`
        INSERT INTO storage_units (unit_name, location_id, max_capacity) VALUES 
        ('Storage Bay A', 1, 100),
        ('Storage Bay B', 2, 80),
        ('Storage Bay C', 3, 120),
        ('Science Rack', 4, 60),
        ('Food Storage', 5, 150),
        ('Return Container', 3, 200),
        ('Waste Container', 3, 300)
      `)
      console.log("Default storage units created")

      // Insert default cargo categories
      await connection.query(`
        INSERT INTO cargo_categories (category_name) VALUES 
        ('food'), ('medicine'), ('equipment'), ('supplies'), ('waste')
      `)
      console.log("Default cargo categories created")

      // Insert default waste reasons
      await connection.query(`
        INSERT INTO waste_reasons (reason_description) VALUES 
        ('expired'), ('damaged'), ('unusable')
      `)
      console.log("Default waste reasons created")

      // Insert default alert types
      await connection.query(`
        INSERT INTO alert_types (type_name) VALUES 
        ('low_stock'), ('expiration'), ('system_warning')
      `)
      console.log("Default alert types created")
    }

    connection.release()
    console.log("Database initialization completed")
  } catch (error) {
    console.error("Database initialization error:", error)
  }
}

// Start the server
const PORT = 3001
server.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`)
  await initializeDatabase()
})

