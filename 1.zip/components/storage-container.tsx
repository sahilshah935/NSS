"use client"

import { useRef, useState } from "react"
import { useFrame } from "@react-three/fiber"
import { Html } from "@react-three/drei"
import type { Container } from "@/types"
import type * as THREE from "three"

interface StorageContainerProps {
  position: [number, number, number]
  container: Container
  onItemMove: (itemId: string, containerId: string) => void
}

export function StorageContainer({ position, container, onItemMove }: StorageContainerProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)
  const [active, setActive] = useState(false)

  // Calculate utilization percentage
  const utilizationPercentage = (container.items.length / container.capacity) * 100

  // Animate on hover
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.scale.x = hovered ? 1.05 : 1
      meshRef.current.scale.y = hovered ? 1.05 : 1
      meshRef.current.scale.z = hovered ? 1.05 : 1
    }
  })

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={() => setActive(!active)}
        receiveShadow
        castShadow
      >
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial
          color={hovered ? "#138808" : "#FFFFFF"}
          wireframe={false}
          transparent={true}
          opacity={0.7}
        />
      </mesh>

      <Html position={[0, 2.2, 0]} center>
        <div className="text-black text-center font-bold" style={{ fontSize: "14px", whiteSpace: "nowrap" }}>
          {container.name}
        </div>
      </Html>

      <Html position={[0, -1.2, 0]}>
        <div className="bg-white p-2 rounded-md shadow-md text-center w-32">
          <div className="text-xs font-bold">{container.name}</div>
          <div className="text-xs">
            {container.items.length}/{container.capacity} items
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
            <div
              className="h-1.5 rounded-full"
              style={{
                width: `${utilizationPercentage}%`,
                backgroundColor: utilizationPercentage > 80 ? "#FF9933" : "#138808",
              }}
            />
          </div>
        </div>
      </Html>

      {active && (
        <Html position={[0, 0, 1.2]}>
          <div className="bg-white p-2 rounded-md shadow-md">
            <h3 className="text-sm font-bold mb-1">{container.name} Contents</h3>
            <ul className="text-xs space-y-1 max-h-32 overflow-auto">
              {container.items.length > 0 ? (
                container.items.map((item) => (
                  <li key={item.id} className="flex justify-between">
                    <span>{item.name}</span>
                    <span className="text-gray-500">{item.weight}kg</span>
                  </li>
                ))
              ) : (
                <li className="text-gray-500">Empty container</li>
              )}
            </ul>
          </div>
        </Html>
      )}
    </group>
  )
}

