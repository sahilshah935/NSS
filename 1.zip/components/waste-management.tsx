"use client"

import { useState } from "react"
import { Trash2, ArrowLeft, AlertTriangle, Search, X, Filter } from "lucide-react"
import type { CargoItem, Container } from "@/types"

interface WasteManagementProps {
  cargoItems: CargoItem[]
  containers: Container[]
  handleItemMove: (itemId: string, containerId: string | null) => void
  handleItemRemove?: (itemId: string) => void
}

export function WasteManagement({ cargoItems, containers, handleItemMove, handleItemRemove }: WasteManagementProps) {
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [disposalPlan, setDisposalPlan] = useState<{
    toDispose: CargoItem[]
    toReturn: CargoItem[]
  } | null>(null)
  const [returnWeight, setReturnWeight] = useState(0)
  const [maxReturnWeight, setMaxReturnWeight] = useState(25) // kg
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState<string | null>(null)
  const [showRemoveConfirm, setShowRemoveConfirm] = useState<string | null>(null)

  // Get expired items
  const now = new Date()
  const expiredItems = cargoItems.filter((item) => {
    if (!item.expiryDate) return false
    const expiryDate = new Date(item.expiryDate)
    return expiryDate < now
  })

  // Get items expiring soon (within 30 days)
  const thirtyDaysFromNow = new Date()
  thirtyDaysFromNow.setDate(now.getDate() + 30)
  const expiringItems = cargoItems.filter((item) => {
    if (!item.expiryDate) return false
    const expiryDate = new Date(item.expiryDate)
    return expiryDate >= now && expiryDate <= thirtyDaysFromNow
  })

  // Get used items (for demo, we'll consider items with "used" in their name)
  const usedItems = cargoItems.filter(
    (item) => item.name.toLowerCase().includes("used") || item.category.toLowerCase().includes("waste"),
  )

  // Toggle item selection
  const toggleItemSelection = (itemId: string) => {
    if (selectedItems.includes(itemId)) {
      setSelectedItems(selectedItems.filter((id) => id !== itemId))
    } else {
      setSelectedItems([...selectedItems, itemId])
    }
  }

  // Generate disposal plan
  const generateDisposalPlan = () => {
    if (selectedItems.length === 0) {
      alert("Please select at least one item to generate a disposal plan.")
      return
    }

    const selectedItemsData = cargoItems.filter((item) => selectedItems.includes(item.id))

    // Sort by priority and weight
    const sortedItems = [...selectedItemsData].sort((a, b) => {
      // First by priority
      const priorityOrder = { high: 0, medium: 1, low: 2 }
      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority]
      if (priorityDiff !== 0) return priorityDiff

      // Then by weight (heavier items are more important to return)
      return b.weight - a.weight
    })

    // Determine which items to return vs dispose based on weight constraints
    let currentWeight = 0
    const toReturn: CargoItem[] = []
    const toDispose: CargoItem[] = []

    for (const item of sortedItems) {
      if (currentWeight + item.weight <= maxReturnWeight) {
        toReturn.push(item)
        currentWeight += item.weight
      } else {
        toDispose.push(item)
      }
    }

    setReturnWeight(currentWeight)
    setDisposalPlan({ toReturn, toDispose })
  }

  // Execute disposal plan
  const executeDisposalPlan = () => {
    if (!disposalPlan) return

    // Mark items for disposal by moving them to a special container or null
    disposalPlan.toDispose.forEach((item) => {
      handleItemMove(item.id, null) // Remove from containers
    })

    // Mark items for return by moving them to a return container
    // In a real app, you might have a specific return container
    disposalPlan.toReturn.forEach((item) => {
      handleItemMove(item.id, "return-container") // Move to return container
    })

    // Reset selection and plan
    setSelectedItems([])
    setDisposalPlan(null)

    // Show success message (in a real app, use a toast notification)
    alert("Disposal plan executed successfully!")
  }

  // Handle item removal
  const confirmRemoveItem = (itemId: string) => {
    setShowRemoveConfirm(itemId)
  }

  const removeItem = (itemId: string) => {
    if (handleItemRemove) {
      handleItemRemove(itemId)

      // Update UI
      setSelectedItems(selectedItems.filter((id) => id !== itemId))
      setShowRemoveConfirm(null)
    }
  }

  const cancelRemove = () => {
    setShowRemoveConfirm(null)
  }

  // Filter items based on search term and status filter
  const filteredItems = cargoItems.filter((item) => {
    // Apply search filter
    const matchesSearch =
      !searchTerm ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.expiryDate && item.expiryDate.toLowerCase().includes(searchTerm.toLowerCase()))

    // Apply status filter
    let matchesStatus = true
    if (filterStatus) {
      const isExpired = item.expiryDate && new Date(item.expiryDate) < now
      const isExpiring = item.expiryDate && !isExpired && new Date(item.expiryDate) <= thirtyDaysFromNow
      const isUsed = item.name.toLowerCase().includes("used") || item.category.toLowerCase().includes("waste")

      switch (filterStatus) {
        case "expired":
          matchesStatus = isExpired
          break
        case "expiring":
          matchesStatus = isExpiring
          break
        case "used":
          matchesStatus = isUsed
          break
        case "good":
          matchesStatus = !isExpired && !isExpiring && !isUsed
          break
      }
    }

    return matchesSearch && matchesStatus
  })

  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
        <h1 className="text-2xl font-bold mb-8 text-[#000080] border-b pb-4">Waste & Cargo Return Management</h1>

        {disposalPlan ? (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-[#000080]">Disposal Plan</h2>
              <div className="flex gap-3">
                <button
                  onClick={() => setDisposalPlan(null)}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors duration-200 shadow-sm"
                >
                  Back
                </button>
                <button
                  onClick={executeDisposalPlan}
                  className="px-4 py-2 bg-[#138808] text-white rounded-lg hover:bg-[#138808]/90 transition-colors duration-200 shadow-md"
                >
                  Execute Plan
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-6 shadow-sm bg-gradient-to-br from-[#FF9933]/5 to-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-[#FF9933]/20 p-2 rounded-full">
                    <ArrowLeft className="h-5 w-5 text-[#FF9933]" />
                  </div>
                  <h3 className="font-bold text-lg">Items to Return ({disposalPlan.toReturn.length})</h3>
                </div>
                <div className="text-sm mb-3 flex justify-between items-center">
                  <span className="font-medium">Total Weight:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{returnWeight.toFixed(1)}kg</span>
                    <span className="text-gray-500">/ {maxReturnWeight}kg</span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                  <div
                    className="h-2 rounded-full bg-[#FF9933] transition-all duration-500"
                    style={{ width: `${(returnWeight / maxReturnWeight) * 100}%` }}
                  />
                </div>
                <ul className="space-y-3 max-h-80 overflow-y-auto pr-2">
                  {disposalPlan.toReturn.map((item) => (
                    <li
                      key={item.id}
                      className="flex justify-between items-center p-3 bg-white rounded-lg border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-200"
                    >
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-sm text-gray-500 flex items-center gap-2">
                          <span>{item.category}</span>
                          <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                          <span>{item.weight}kg</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          item.priority === "high"
                            ? "bg-red-100 text-red-800"
                            : item.priority === "medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-green-100 text-green-800"
                        }`}
                      >
                        {item.priority}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="border rounded-lg p-6 shadow-sm bg-gradient-to-br from-red-50 to-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-red-100 p-2 rounded-full">
                    <Trash2 className="h-5 w-5 text-red-500" />
                  </div>
                  <h3 className="font-bold text-lg">Items to Dispose ({disposalPlan.toDispose.length})</h3>
                </div>
                <ul className="space-y-3 max-h-80 overflow-y-auto pr-2">
                  {disposalPlan.toDispose.map((item) => (
                    <li
                      key={item.id}
                      className="flex justify-between items-center p-3 bg-white rounded-lg border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-200"
                    >
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-sm text-gray-500 flex items-center gap-2">
                          <span>{item.category}</span>
                          <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                          <span>{item.weight}kg</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          item.priority === "high"
                            ? "bg-red-100 text-red-800"
                            : item.priority === "medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-green-100 text-green-800"
                        }`}
                      >
                        {item.priority}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-red-50 to-white rounded-lg p-6 border border-red-100 shadow-md hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-red-100 p-2 rounded-full">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                  </div>
                  <h3 className="font-bold text-lg">Expired Items</h3>
                </div>
                <div className="text-3xl font-bold text-red-600">{expiredItems.length}</div>
                <div className="text-sm text-gray-600 mt-2">Items past expiration date</div>
                {expiredItems.length > 0 && (
                  <button
                    onClick={() => setFilterStatus("expired")}
                    className="mt-4 text-sm text-red-600 hover:text-red-800 font-medium flex items-center gap-1"
                  >
                    <Filter className="h-3 w-3" /> Filter expired items
                  </button>
                )}
              </div>

              <div className="bg-gradient-to-br from-yellow-50 to-white rounded-lg p-6 border border-yellow-100 shadow-md hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  </div>
                  <h3 className="font-bold text-lg">Expiring Soon</h3>
                </div>
                <div className="text-3xl font-bold text-yellow-600">{expiringItems.length}</div>
                <div className="text-sm text-gray-600 mt-2">Items expiring in 30 days</div>
                {expiringItems.length > 0 && (
                  <button
                    onClick={() => setFilterStatus("expiring")}
                    className="mt-4 text-sm text-yellow-600 hover:text-yellow-800 font-medium flex items-center gap-1"
                  >
                    <Filter className="h-3 w-3" /> Filter expiring items
                  </button>
                )}
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-white rounded-lg p-6 border border-blue-100 shadow-md hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <Trash2 className="h-5 w-5 text-blue-500" />
                  </div>
                  <h3 className="font-bold text-lg">Used Items</h3>
                </div>
                <div className="text-3xl font-bold text-blue-600">{usedItems.length}</div>
                <div className="text-sm text-gray-600 mt-2">Items marked as used/waste</div>
                {usedItems.length > 0 && (
                  <button
                    onClick={() => setFilterStatus("used")}
                    className="mt-4 text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
                  >
                    <Filter className="h-3 w-3" /> Filter used items
                  </button>
                )}
              </div>
            </div>

            <div className="mb-6 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <h2 className="text-xl font-bold text-[#000080]">Items for Disposal/Return</h2>

              <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
                <div className="relative flex-1 md:w-64">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933] transition-all duration-200"
                  />
                  {searchTerm && (
                    <button
                      onClick={() => setSearchTerm("")}
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  )}
                </div>

                {filterStatus && (
                  <div className="flex items-center gap-2 bg-blue-50 px-3 py-1.5 rounded-lg text-sm">
                    <span>
                      Filtering:
                      <span className="font-medium ml-1">
                        {filterStatus === "expired"
                          ? "Expired Items"
                          : filterStatus === "expiring"
                            ? "Expiring Soon"
                            : filterStatus === "used"
                              ? "Used Items"
                              : "Good Items"}
                      </span>
                    </span>
                    <button onClick={() => setFilterStatus(null)} className="text-gray-500 hover:text-gray-700">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg">
                    <span className="text-sm font-medium whitespace-nowrap">Max Return:</span>
                    <input
                      type="number"
                      value={maxReturnWeight}
                      onChange={(e) => setMaxReturnWeight(Number(e.target.value))}
                      className="w-16 p-1 border rounded text-center focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                      min="1"
                    />
                    <span className="text-sm">kg</span>
                  </div>

                  <button
                    onClick={generateDisposalPlan}
                    disabled={selectedItems.length === 0}
                    className={`px-4 py-2 rounded-lg shadow-md transition-all duration-200 ${
                      selectedItems.length === 0
                        ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                        : "bg-[#FF9933] text-white hover:bg-[#FF9933]/90 hover:shadow-lg"
                    }`}
                  >
                    Generate Plan
                  </button>
                </div>
              </div>
            </div>

            <div className="border rounded-lg overflow-hidden shadow-md">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={
                            filteredItems.length > 0 && filteredItems.every((item) => selectedItems.includes(item.id))
                          }
                          onChange={() => {
                            if (filteredItems.every((item) => selectedItems.includes(item.id))) {
                              // Deselect all filtered items
                              setSelectedItems(
                                selectedItems.filter((id) => !filteredItems.some((item) => item.id === id)),
                              )
                            } else {
                              // Select all filtered items
                              const newSelectedItems = [...selectedItems]
                              filteredItems.forEach((item) => {
                                if (!newSelectedItems.includes(item.id)) {
                                  newSelectedItems.push(item.id)
                                }
                              })
                              setSelectedItems(newSelectedItems)
                            }
                          }}
                          className="rounded border-gray-300 text-[#FF9933] focus:ring-[#FF9933]"
                        />
                        <span>Select</span>
                      </div>
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Category
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Weight
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Expiry Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Priority
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredItems.map((item) => {
                    const isExpired = item.expiryDate && new Date(item.expiryDate) < now
                    const isExpiring = item.expiryDate && !isExpired && new Date(item.expiryDate) <= thirtyDaysFromNow
                    const isUsed =
                      item.name.toLowerCase().includes("used") || item.category.toLowerCase().includes("waste")

                    return (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors duration-150">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="checkbox"
                            checked={selectedItems.includes(item.id)}
                            onChange={() => toggleItemSelection(item.id)}
                            className="rounded border-gray-300 text-[#FF9933] focus:ring-[#FF9933]"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{item.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.category}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.weight} kg</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.expiryDate || "N/A"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              item.priority === "high"
                                ? "bg-red-100 text-red-800"
                                : item.priority === "medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-green-100 text-green-800"
                            }`}
                          >
                            {item.priority}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {isExpired ? (
                            <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                              Expired
                            </span>
                          ) : isExpiring ? (
                            <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                              Expiring Soon
                            </span>
                          ) : isUsed ? (
                            <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                              Used
                            </span>
                          ) : (
                            <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Good
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          {handleItemRemove &&
                            (showRemoveConfirm === item.id ? (
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => removeItem(item.id)}
                                  className="text-red-600 hover:text-red-800 font-medium"
                                >
                                  Confirm
                                </button>
                                <button
                                  onClick={cancelRemove}
                                  className="text-gray-500 hover:text-gray-700 font-medium"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => confirmRemoveItem(item.id)}
                                className="text-red-600 hover:text-red-800 font-medium flex items-center gap-1"
                              >
                                <Trash2 className="h-4 w-4" /> Remove
                              </button>
                            ))}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

