"use client"

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import type { Alert, UtilizationData } from "@/types"

interface DashboardProps {
  utilization: UtilizationData[]
  alerts: Alert[]
}

export function Dashboard({ utilization, alerts }: DashboardProps) {
  // Data for category distribution
  const categoryData = [
    { name: "Food", value: 35 },
    { name: "Equipment", value: 25 },
    { name: "Medical", value: 15 },
    { name: "Science", value: 20 },
    { name: "Personal", value: 5 },
  ]

  // Colors for the pie chart
  const COLORS = ["#FF9933", "#FFFFFF", "#138808", "#000080", "#6B7280"]

  return (
    <div className="container mx-auto p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-lg font-bold mb-4">Storage Utilization</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={utilization}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="current" name="Current Items" fill="#FF9933" />
              <Bar dataKey="capacity" name="Total Capacity" fill="#138808" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-lg font-bold mb-4">Cargo Category Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-4 rounded-lg shadow md:col-span-2">
          <h2 className="text-lg font-bold mb-4">System Alerts</h2>
          <div className="space-y-2">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3 rounded-md ${
                  alert.severity === "high"
                    ? "bg-red-100 border-l-4 border-red-500"
                    : alert.severity === "medium"
                      ? "bg-yellow-100 border-l-4 border-yellow-500"
                      : "bg-blue-100 border-l-4 border-blue-500"
                }`}
              >
                <div className="flex justify-between">
                  <h3 className="font-medium">{alert.title}</h3>
                  <span className="text-sm text-gray-500">{alert.date}</span>
                </div>
                <p className="text-sm mt-1">{alert.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

