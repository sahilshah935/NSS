"use client"

import { useState } from "react"
import { User, UserPlus, UserCheck, UserX, Shield, Edit, Trash, Check } from "lucide-react"

interface UserData {
  id: string
  username: string
  name: string
  role: string
  lastLogin?: string
  status: "active" | "inactive"
}

export function AccessControl() {
  const [users, setUsers] = useState<UserData[]>([
    {
      id: "user-1",
      username: "commander",
      name: "Rakesh Sharma",
      role: "admin",
      lastLogin: "2024-03-25 08:30",
      status: "active",
    },
    {
      id: "user-2",
      username: "scientist",
      name: "Kalpana Chawla",
      role: "user",
      lastLogin: "2024-03-24 14:15",
      status: "active",
    },
    {
      id: "user-3",
      username: "engineer",
      name: "Sunita Williams",
      role: "user",
      lastLogin: "2024-03-23 09:45",
      status: "active",
    },
    {
      id: "user-4",
      username: "mission_control",
      name: "A.P.J. Abdul Kalam",
      role: "readonly",
      lastLogin: "2024-03-20 11:20",
      status: "inactive",
    },
  ])

  const [editingUser, setEditingUser] = useState<UserData | null>(null)
  const [isAddingUser, setIsAddingUser] = useState(false)
  const [newUser, setNewUser] = useState<Partial<UserData>>({
    username: "",
    name: "",
    role: "user",
    status: "active",
  })

  // Permissions data
  const permissions = [
    { id: "view_cargo", name: "View Cargo Items", roles: ["admin", "user", "readonly"] },
    { id: "add_cargo", name: "Add Cargo Items", roles: ["admin", "user"] },
    { id: "edit_cargo", name: "Edit Cargo Items", roles: ["admin", "user"] },
    { id: "delete_cargo", name: "Delete Cargo Items", roles: ["admin"] },
    { id: "manage_users", name: "Manage Users", roles: ["admin"] },
    { id: "view_reports", name: "View Reports", roles: ["admin", "user", "readonly"] },
    { id: "waste_management", name: "Waste Management", roles: ["admin", "user"] },
    { id: "3d_view", name: "3D Visualization", roles: ["admin", "user", "readonly"] },
  ]

  // Handle user edit
  const handleEditUser = (user: UserData) => {
    setEditingUser(user)
    setIsAddingUser(false)
  }

  // Handle user update
  const handleUpdateUser = () => {
    if (!editingUser) return

    setUsers(users.map((user) => (user.id === editingUser.id ? editingUser : user)))

    setEditingUser(null)
  }

  // Handle user add
  const handleAddUser = () => {
    const id = `user-${Date.now()}`
    const user: UserData = {
      id,
      username: newUser.username || "",
      name: newUser.name || "",
      role: (newUser.role as string) || "user",
      status: (newUser.status as "active" | "inactive") || "active",
    }

    setUsers([...users, user])
    setNewUser({
      username: "",
      name: "",
      role: "user",
      status: "active",
    })
    setIsAddingUser(false)
  }

  // Handle user delete
  const handleDeleteUser = (userId: string) => {
    if (confirm("Are you sure you want to delete this user?")) {
      setUsers(users.filter((user) => user.id !== userId))
    }
  }

  // Get role badge color
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800"
      case "user":
        return "bg-blue-100 text-blue-800"
      case "readonly":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Access Control</h1>
          <button
            onClick={() => {
              setIsAddingUser(true)
              setEditingUser(null)
            }}
            className="px-4 py-2 bg-[#FF9933] text-white rounded-md hover:bg-[#FF9933]/90 flex items-center gap-2"
          >
            <UserPlus className="h-4 w-4" />
            Add User
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
            <div className="flex items-center gap-2 mb-3">
              <User className="h-5 w-5 text-blue-500" />
              <h3 className="font-bold">Total Users</h3>
            </div>
            <div className="text-2xl font-bold">{users.length}</div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-md p-4">
            <div className="flex items-center gap-2 mb-3">
              <UserCheck className="h-5 w-5 text-green-500" />
              <h3 className="font-bold">Active Users</h3>
            </div>
            <div className="text-2xl font-bold">{users.filter((user) => user.status === "active").length}</div>
          </div>

          <div className="bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-5 w-5 text-red-500" />
              <h3 className="font-bold">Admin Users</h3>
            </div>
            <div className="text-2xl font-bold">{users.filter((user) => user.role === "admin").length}</div>
          </div>
        </div>

        {editingUser || isAddingUser ? (
          <div className="bg-gray-50 border rounded-md p-4 mb-6">
            <h2 className="text-lg font-bold mb-4">{isAddingUser ? "Add New User" : "Edit User"}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                <input
                  type="text"
                  value={isAddingUser ? newUser.username : editingUser?.username}
                  onChange={(e) => {
                    if (isAddingUser) {
                      setNewUser({ ...newUser, username: e.target.value })
                    } else if (editingUser) {
                      setEditingUser({ ...editingUser, username: e.target.value })
                    }
                  }}
                  className="w-full p-2 border rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={isAddingUser ? newUser.name : editingUser?.name}
                  onChange={(e) => {
                    if (isAddingUser) {
                      setNewUser({ ...newUser, name: e.target.value })
                    } else if (editingUser) {
                      setEditingUser({ ...editingUser, name: e.target.value })
                    }
                  }}
                  className="w-full p-2 border rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                <select
                  value={isAddingUser ? newUser.role : editingUser?.role}
                  onChange={(e) => {
                    if (isAddingUser) {
                      setNewUser({ ...newUser, role: e.target.value })
                    } else if (editingUser) {
                      setEditingUser({ ...editingUser, role: e.target.value })
                    }
                  }}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="admin">Admin</option>
                  <option value="user">User</option>
                  <option value="readonly">Read Only</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={isAddingUser ? newUser.status : editingUser?.status}
                  onChange={(e) => {
                    if (isAddingUser) {
                      setNewUser({ ...newUser, status: e.target.value as "active" | "inactive" })
                    } else if (editingUser) {
                      setEditingUser({ ...editingUser, status: e.target.value as "active" | "inactive" })
                    }
                  }}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>

            {!isAddingUser && (
              <div className="mb-4">
                <h3 className="font-medium mb-2">Role Permissions</h3>
                <div className="bg-white p-3 border rounded-md">
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {permissions.map((permission) => (
                      <li key={permission.id} className="flex items-center gap-2">
                        {permission.roles.includes(editingUser?.role || "") ? (
                          <UserCheck className="h-4 w-4 text-green-500" />
                        ) : (
                          <UserX className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">{permission.name}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2">
              <button
                onClick={() => {
                  setEditingUser(null)
                  setIsAddingUser(false)
                }}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={isAddingUser ? handleAddUser : handleUpdateUser}
                className="px-4 py-2 bg-[#138808] text-white rounded-md hover:bg-[#138808]/90"
              >
                {isAddingUser ? "Add User" : "Update User"}
              </button>
            </div>
          </div>
        ) : (
          <div className="border rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Login
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-[#000080] flex items-center justify-center text-white">
                          <span>{user.name.charAt(0)}</span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{user.name}</div>
                          <div className="text-sm text-gray-500">@{user.username}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleBadgeColor(user.role)}`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          user.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {user.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.lastLogin || "Never"}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex gap-2">
                        <button onClick={() => handleEditUser(user)} className="text-blue-600 hover:text-blue-900">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-900">
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-6">
          <h2 className="text-lg font-bold mb-4">Role Permissions</h2>
          <div className="border rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Permission
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Admin
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Read Only
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {permissions.map((permission) => (
                  <tr key={permission.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{permission.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {permission.roles.includes("admin") ? (
                        <Check className="h-5 w-5 text-green-500" />
                      ) : (
                        <span className="text-red-500">✕</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {permission.roles.includes("user") ? (
                        <Check className="h-5 w-5 text-green-500" />
                      ) : (
                        <span className="text-red-500">✕</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {permission.roles.includes("readonly") ? (
                        <Check className="h-5 w-5 text-green-500" />
                      ) : (
                        <span className="text-red-500">✕</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

