"use client"

import { useRef, useState } from "react"
import { useFrame } from "@react-three/fiber"
import { Html } from "@react-three/drei"
import { useDrag } from "@use-gesture/react"
import type { CargoItem as CargoItemType } from "@/types"
import type * as THREE from "three"

interface CargoItemProps {
  position: [number, number, number]
  item: CargoItemType
}

export function CargoItem({ position, item }: CargoItemProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)
  const [pos, setPos] = useState(position)
  const [showDetails, setShowDetails] = useState(false)

  // Color based on priority
  const getColorByPriority = () => {
    switch (item.priority) {
      case "high":
        return "#FF9933" // Orange for high priority
      case "medium":
        return "#FFFFFF" // White for medium priority
      case "low":
        return "#138808" // Green for low priority
      default:
        return "#CCCCCC"
    }
  }

  // Animate on hover
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01
      if (hovered) {
        meshRef.current.scale.setScalar(1.1)
      } else {
        meshRef.current.scale.setScalar(1)
      }
    }
  })

  // Make the item draggable
  const bind = useDrag(({ offset: [x, y] }) => {
    setPos([x / 100, position[1], y / 100])
  })

  return (
    <group position={pos}>
      <mesh
        ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={() => setShowDetails(!showDetails)}
        {...bind()}
        castShadow
      >
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial color={getColorByPriority()} />
      </mesh>

      <Html position={[0, 0.6, 0]} center>
        <div className="text-black text-center font-bold" style={{ fontSize: "12px", whiteSpace: "nowrap" }}>
          {item.name}
        </div>
      </Html>

      {showDetails && (
        <Html position={[0, 0, 0.5]}>
          <div className="bg-white p-2 rounded-md shadow-md w-40">
            <h3 className="text-sm font-bold">{item.name}</h3>
            <div className="text-xs mt-1">
              <div>
                <span className="font-medium">Weight:</span> {item.weight}kg
              </div>
              <div>
                <span className="font-medium">Expiry:</span> {item.expiryDate}
              </div>
              <div>
                <span className="font-medium">Priority:</span> {item.priority}
              </div>
              <div>
                <span className="font-medium">Category:</span> {item.category}
              </div>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}

