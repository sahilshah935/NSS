"use client"

import { CuboidIcon as Cube, BarChart2, Search, Trash2, Users, Lightbulb } from "lucide-react"

interface NavigationProps {
  activeView: string
  setActiveView: (view: string) => void
}

export function Navigation({ activeView, setActiveView }: NavigationProps) {
  const navItems = [
    { id: "3d-view", label: "3D View", icon: Cube },
    { id: "dashboard", label: "Dashboard", icon: BarChart2 },
    { id: "search", label: "Search", icon: Search },
    { id: "waste", label: "Waste Management", icon: Trash2 },
    { id: "advisor", label: "Storage Advisor", icon: Lightbulb },
    { id: "access", label: "Access Control", icon: Users },
  ]

  return (
    <nav className="bg-gradient-to-r from-[#000080] to-[#000080]/90 text-white shadow-md">
      <div className="container mx-auto">
        <ul className="flex flex-wrap">
          {navItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setActiveView(item.id)}
                className={`flex items-center gap-2 px-6 py-4 transition-all duration-200 ${
                  activeView === item.id
                    ? "bg-[#FF9933] text-white shadow-inner font-medium"
                    : "hover:bg-[#000080]/80 hover:text-white/90"
                }`}
              >
                <item.icon
                  className={`h-5 w-5 transition-transform duration-200 ${activeView === item.id ? "scale-110" : ""}`}
                />
                <span>{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  )
}

