"use client"

import { useState, useEffect } from "react"
import { Search, Trash2, AlertCircle, Filter, X, Calendar, Package, Tag, SortAsc, SortDesc, Plus } from "lucide-react"
import type { CargoItem, Container } from "@/types"

interface SearchPanelProps {
  cargoItems: CargoItem[]
  containers: Container[]
  handleItemRemove?: (itemId: string) => void
  onAddItem?: () => void
}

export function SearchPanel({ cargoItems, containers, handleItemRemove, onAddItem }: SearchPanelProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<CargoItem[]>([])
  const [selectedItem, setSelectedItem] = useState<CargoItem | null>(null)
  const [showRemoveConfirm, setShowRemoveConfirm] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)

  // Filter states
  const [sectionFilter, setSectionFilter] = useState<string | null>(null)
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null)
  const [expiryFilter, setExpiryFilter] = useState<string | null>(null)
  const [priorityFilter, setPriorityFilter] = useState<string | null>(null)
  const [sortBy, setSortBy] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")

  // Initialize with all items
  useEffect(() => {
    setSearchResults(cargoItems)
  }, [cargoItems])

  // Handle search
  const handleSearch = () => {
    applyFilters()
  }

  // Apply all filters and search
  const applyFilters = () => {
    let results = [...cargoItems]

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      results = results.filter(
        (item) =>
          item.name.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query) ||
          item.id.toLowerCase().includes(query),
      )
    }

    // Apply section filter
    if (sectionFilter) {
      results = results.filter((item) => {
        const container = containers.find((c) => c.id === item.containerId)
        return container && container.section === sectionFilter
      })
    }

    // Apply category filter
    if (categoryFilter) {
      results = results.filter((item) => item.category === categoryFilter)
    }

    // Apply expiry filter
    if (expiryFilter) {
      const now = new Date()
      const thirtyDaysFromNow = new Date()
      thirtyDaysFromNow.setDate(now.getDate() + 30)

      switch (expiryFilter) {
        case "expired":
          results = results.filter((item) => item.expiryDate && new Date(item.expiryDate) < now)
          break
        case "expiring-soon":
          results = results.filter(
            (item) =>
              item.expiryDate && new Date(item.expiryDate) >= now && new Date(item.expiryDate) <= thirtyDaysFromNow,
          )
          break
        case "valid":
          results = results.filter((item) => !item.expiryDate || new Date(item.expiryDate) > thirtyDaysFromNow)
          break
      }
    }

    // Apply priority filter
    if (priorityFilter) {
      results = results.filter((item) => item.priority === priorityFilter)
    }

    // Apply sorting
    if (sortBy) {
      results.sort((a, b) => {
        let comparison = 0

        switch (sortBy) {
          case "name":
            comparison = a.name.localeCompare(b.name)
            break
          case "category":
            comparison = a.category.localeCompare(b.category)
            break
          case "weight":
            comparison = a.weight - b.weight
            break
          case "expiry":
            // Handle null expiry dates
            if (!a.expiryDate && !b.expiryDate) comparison = 0
            else if (!a.expiryDate) comparison = 1
            else if (!b.expiryDate) comparison = -1
            else comparison = new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()
            break
          case "priority":
            const priorityOrder = { high: 0, medium: 1, low: 2 }
            comparison = priorityOrder[a.priority] - priorityOrder[b.priority]
            break
        }

        return sortDirection === "asc" ? comparison : -comparison
      })
    }

    setSearchResults(results)
  }

  // Reset all filters
  const resetFilters = () => {
    setSearchQuery("")
    setSectionFilter(null)
    setCategoryFilter(null)
    setExpiryFilter(null)
    setPriorityFilter(null)
    setSortBy(null)
    setSortDirection("asc")
    setSearchResults(cargoItems)
  }

  // Get container name by ID
  const getContainerName = (containerId: string | null) => {
    if (!containerId) return "Unassigned"
    const container = containers.find((c) => c.id === containerId)
    return container ? container.name : "Unknown"
  }

  // Get container section by ID
  const getContainerSection = (containerId: string | null) => {
    if (!containerId) return "Unassigned"
    const container = containers.find((c) => c.id === containerId)
    return container ? container.section : "Unknown"
  }

  // Generate retrieval steps
  const generateRetrievalSteps = (item: CargoItem) => {
    if (!item.containerId) return ["Item is not stored in any container"]

    const container = containers.find((c) => c.id === item.containerId)
    if (!container) return ["Container information not found"]

    return [
      `1. Go to ${container.name} in section ${container.section}`,
      `2. Open the container using access code ${container.id.slice(-4)}`,
      `3. The item is located on ${item.position === "top" ? "the top" : item.position === "middle" ? "the middle" : "the bottom"} shelf`,
      `4. Look for packaging labeled "${item.name}"`,
      `5. Scan barcode before removing to update inventory`,
    ]
  }

  // Handle item removal
  const confirmRemoveItem = (itemId: string) => {
    setShowRemoveConfirm(itemId)
  }

  const removeItem = (itemId: string) => {
    if (handleItemRemove) {
      handleItemRemove(itemId)

      // Update UI
      setSearchResults(searchResults.filter((item) => item.id !== itemId))
      if (selectedItem?.id === itemId) {
        setSelectedItem(null)
      }
      setShowRemoveConfirm(null)
    }
  }

  const cancelRemove = () => {
    setShowRemoveConfirm(null)
  }

  // Get unique sections, categories for filters
  const uniqueSections = Array.from(new Set(containers.map((container) => container.section)))
  const uniqueCategories = Array.from(new Set(cargoItems.map((item) => item.category)))

  // Toggle sort direction
  const toggleSortDirection = () => {
    setSortDirection(sortDirection === "asc" ? "desc" : "asc")
  }

  // Apply a sort
  const applySorting = (field: string) => {
    if (sortBy === field) {
      toggleSortDirection()
    } else {
      setSortBy(field)
      setSortDirection("asc")
    }
  }

  // Effect to apply filters when they change
  useEffect(() => {
    applyFilters()
  }, [sectionFilter, categoryFilter, expiryFilter, priorityFilter, sortBy, sortDirection])

  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933] transition-all duration-200"
              placeholder="Search for cargo items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery("")
                  applyFilters()
                }}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleSearch}
              className="px-6 py-3 bg-[#FF9933] text-white rounded-lg hover:bg-[#FF9933]/90 transition-colors duration-200 shadow-md hover:shadow-lg"
            >
              Search
            </button>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 py-3 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2 ${
                showFilters || (sectionFilter || categoryFilter || expiryFilter || priorityFilter || sortBy)
                  ? "bg-[#138808] text-white hover:bg-[#138808]/90"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Filter className="h-5 w-5" />
              <span className="hidden md:inline">Filters</span>
              {(sectionFilter || categoryFilter || expiryFilter || priorityFilter || sortBy) && (
                <span className="inline-flex items-center justify-center w-5 h-5 ml-1 text-xs font-bold text-white bg-red-500 rounded-full">
                  {[sectionFilter, categoryFilter, expiryFilter, priorityFilter, sortBy].filter(Boolean).length}
                </span>
              )}
            </button>
            {onAddItem && (
              <button
                onClick={onAddItem}
                className="px-4 py-3 bg-[#138808] text-white rounded-lg hover:bg-[#138808]/90 transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <Plus className="h-5 w-5" />
                <span className="hidden md:inline">Add Item</span>
              </button>
            )}
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200 animate-in fade-in duration-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-700">Filter Options</h3>
              <button onClick={resetFilters} className="text-sm text-[#FF9933] hover:text-[#FF9933]/80 font-medium">
                Reset All Filters
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Section Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Section</label>
                <select
                  value={sectionFilter || ""}
                  onChange={(e) => setSectionFilter(e.target.value || null)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                >
                  <option value="">All Sections</option>
                  {uniqueSections.map((section) => (
                    <option key={section} value={section}>
                      {section}
                    </option>
                  ))}
                </select>
              </div>

              {/* Category Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  value={categoryFilter || ""}
                  onChange={(e) => setCategoryFilter(e.target.value || null)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                >
                  <option value="">All Categories</option>
                  {uniqueCategories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              {/* Expiry Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Status</label>
                <select
                  value={expiryFilter || ""}
                  onChange={(e) => setExpiryFilter(e.target.value || null)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                >
                  <option value="">All Items</option>
                  <option value="expired">Expired</option>
                  <option value="expiring-soon">Expiring Soon (30 days)</option>
                  <option value="valid">Valid</option>
                </select>
              </div>

              {/* Priority Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <select
                  value={priorityFilter || ""}
                  onChange={(e) => setPriorityFilter(e.target.value || null)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                >
                  <option value="">All Priorities</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => applySorting("name")}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center gap-1 ${
                    sortBy === "name" ? "bg-[#FF9933] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Name
                  {sortBy === "name" &&
                    (sortDirection === "asc" ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)}
                </button>
                <button
                  onClick={() => applySorting("category")}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center gap-1 ${
                    sortBy === "category" ? "bg-[#FF9933] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Category
                  {sortBy === "category" &&
                    (sortDirection === "asc" ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)}
                </button>
                <button
                  onClick={() => applySorting("weight")}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center gap-1 ${
                    sortBy === "weight" ? "bg-[#FF9933] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Weight
                  {sortBy === "weight" &&
                    (sortDirection === "asc" ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)}
                </button>
                <button
                  onClick={() => applySorting("expiry")}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center gap-1 ${
                    sortBy === "expiry" ? "bg-[#FF9933] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Expiry Date
                  {sortBy === "expiry" &&
                    (sortDirection === "asc" ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)}
                </button>
                <button
                  onClick={() => applySorting("priority")}
                  className={`px-3 py-1.5 text-sm rounded-md flex items-center gap-1 ${
                    sortBy === "priority" ? "bg-[#FF9933] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  Priority
                  {sortBy === "priority" &&
                    (sortDirection === "asc" ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Active Filters Display */}
        {(sectionFilter || categoryFilter || expiryFilter || priorityFilter || sortBy) && !showFilters && (
          <div className="mb-4 flex flex-wrap gap-2">
            {sectionFilter && (
              <div className="inline-flex items-center bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
                <Package className="h-3 w-3 mr-1" />
                Section: {sectionFilter}
                <button
                  onClick={() => {
                    setSectionFilter(null)
                    applyFilters()
                  }}
                  className="ml-1 text-blue-500 hover:text-blue-700"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            {categoryFilter && (
              <div className="inline-flex items-center bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm">
                <Tag className="h-3 w-3 mr-1" />
                Category: {categoryFilter}
                <button
                  onClick={() => {
                    setCategoryFilter(null)
                    applyFilters()
                  }}
                  className="ml-1 text-green-500 hover:text-green-700"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            {expiryFilter && (
              <div className="inline-flex items-center bg-yellow-50 text-yellow-700 px-3 py-1 rounded-full text-sm">
                <Calendar className="h-3 w-3 mr-1" />
                Expiry:{" "}
                {expiryFilter === "expired" ? "Expired" : expiryFilter === "expiring-soon" ? "Expiring Soon" : "Valid"}
                <button
                  onClick={() => {
                    setExpiryFilter(null)
                    applyFilters()
                  }}
                  className="ml-1 text-yellow-500 hover:text-yellow-700"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            {priorityFilter && (
              <div className="inline-flex items-center bg-red-50 text-red-700 px-3 py-1 rounded-full text-sm">
                <AlertCircle className="h-3 w-3 mr-1" />
                Priority: {priorityFilter}
                <button
                  onClick={() => {
                    setPriorityFilter(null)
                    applyFilters()
                  }}
                  className="ml-1 text-red-500 hover:text-red-700"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            {sortBy && (
              <div className="inline-flex items-center bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm">
                {sortDirection === "asc" ? <SortAsc className="h-3 w-3 mr-1" /> : <SortDesc className="h-3 w-3 mr-1" />}
                Sort: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)} ({sortDirection === "asc" ? "A-Z" : "Z-A"})
                <button
                  onClick={() => {
                    setSortBy(null)
                    applyFilters()
                  }}
                  className="ml-1 text-purple-500 hover:text-purple-700"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            <button
              onClick={resetFilters}
              className="inline-flex items-center bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-200"
            >
              Clear All
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-[#000080]">Cargo Items</h2>
              <div className="text-sm text-gray-500">
                Showing {searchResults.length} of {cargoItems.length} items
              </div>
            </div>

            {searchResults.length === 0 ? (
              <div className="text-gray-500 text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex flex-col items-center">
                  <AlertCircle className="h-12 w-12 text-gray-400 mb-3" />
                  <p className="text-lg">No items found matching your criteria</p>
                  <button
                    onClick={resetFilters}
                    className="mt-4 px-4 py-2 bg-[#FF9933] text-white rounded-md hover:bg-[#FF9933]/90 transition-colors duration-200"
                  >
                    Reset Filters
                  </button>
                </div>
              </div>
            ) : (
              <div className="border rounded-lg overflow-hidden shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Category
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Location
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Priority
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {searchResults.map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors duration-150">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{item.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.category}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {getContainerName(item.containerId)}
                          <span className="text-xs text-gray-400 block">{getContainerSection(item.containerId)}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              item.priority === "high"
                                ? "bg-red-100 text-red-800"
                                : item.priority === "medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-green-100 text-green-800"
                            }`}
                          >
                            {item.priority}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <div className="flex gap-3">
                            <button
                              onClick={() => setSelectedItem(item)}
                              className="text-[#000080] hover:text-[#000080]/80 font-medium"
                            >
                              View Details
                            </button>
                            {handleItemRemove &&
                              (showRemoveConfirm === item.id ? (
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => removeItem(item.id)}
                                    className="text-red-600 hover:text-red-800 font-medium"
                                  >
                                    Confirm
                                  </button>
                                  <button
                                    onClick={cancelRemove}
                                    className="text-gray-500 hover:text-gray-700 font-medium"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => confirmRemoveItem(item.id)}
                                  className="text-red-600 hover:text-red-800 font-medium flex items-center gap-1"
                                >
                                  <Trash2 className="h-4 w-4" /> Remove
                                </button>
                              ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div>
            {selectedItem ? (
              <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 shadow-sm sticky top-6">
                <h2 className="text-xl font-bold mb-3 text-[#000080]">{selectedItem.name}</h2>
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">ID:</span>
                    <span>{selectedItem.id}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Category:</span>
                    <span>{selectedItem.category}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Weight:</span>
                    <span>{selectedItem.weight}kg</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Expiry Date:</span>
                    <span>{selectedItem.expiryDate || "N/A"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Location:</span>
                    <span>{getContainerName(selectedItem.containerId)}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Section:</span>
                    <span>{getContainerSection(selectedItem.containerId)}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Position:</span>
                    <span className="capitalize">{selectedItem.position || "Unknown"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-medium text-gray-600">Priority:</span>
                    <span
                      className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        selectedItem.priority === "high"
                          ? "bg-red-100 text-red-800"
                          : selectedItem.priority === "medium"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                      }`}
                    >
                      {selectedItem.priority}
                    </span>
                  </div>
                </div>

                <h3 className="font-bold text-sm mb-3 text-[#000080]">Retrieval Steps:</h3>
                <ul className="space-y-2 text-sm bg-white p-4 rounded-md border border-gray-200">
                  {generateRetrievalSteps(selectedItem).map((step, index) => (
                    <li key={index} className="flex gap-2 items-start">
                      <div className="flex-shrink-0 w-1 h-1 rounded-full bg-[#FF9933] mt-2"></div>
                      <div>{step}</div>
                    </li>
                  ))}
                </ul>

                {handleItemRemove && (
                  <div className="mt-6">
                    <button
                      onClick={() => confirmRemoveItem(selectedItem.id)}
                      className="w-full py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors duration-200 flex items-center justify-center gap-2"
                    >
                      <Trash2 className="h-4 w-4" /> Remove Item
                    </button>

                    {showRemoveConfirm === selectedItem.id && (
                      <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-md">
                        <p className="text-sm text-red-800 mb-2">Are you sure you want to remove this item?</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => removeItem(selectedItem.id)}
                            className="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
                          >
                            Yes, Remove
                          </button>
                          <button
                            onClick={cancelRemove}
                            className="px-3 py-1 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 text-sm"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 text-center h-full flex items-center justify-center">
                <div className="text-gray-500">
                  <Search className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                  <p>Select an item to view details</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

