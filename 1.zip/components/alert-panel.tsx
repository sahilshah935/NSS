"use client"

import { useState } from "react"
import { X, Bell } from "lucide-react"
import type { Alert } from "@/types"

interface AlertPanelProps {
  alerts: Alert[]
}

export function AlertPanel({ alerts }: AlertPanelProps) {
  const [isOpen, setIsOpen] = useState(false)
  const highPriorityAlerts = alerts.filter((alert) => alert.severity === "high")

  if (highPriorityAlerts.length === 0) return null

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center justify-center w-12 h-12 bg-red-500 text-white rounded-full shadow-lg hover:bg-red-600 relative"
        >
          <Bell className="h-6 w-6" />
          <span className="absolute -top-1 -right-1 bg-white text-red-500 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
            {highPriorityAlerts.length}
          </span>
        </button>
      ) : (
        <div className="bg-white rounded-lg shadow-xl w-80 overflow-hidden">
          <div className="bg-red-500 text-white p-3 flex justify-between items-center">
            <h3 className="font-bold">Critical Alerts</h3>
            <button onClick={() => setIsOpen(false)}>
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="max-h-80 overflow-y-auto">
            {highPriorityAlerts.map((alert) => (
              <div key={alert.id} className="p-3 border-b">
                <div className="font-medium">{alert.title}</div>
                <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                <div className="text-xs text-gray-500 mt-1">{alert.date}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

