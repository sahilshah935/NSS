"use client"

import { useState } from "react"
import { User, Key, Shield, Clock, LogOut, ArrowLeft, Check } from "lucide-react"
import type { User as UserType } from "@/types"

interface AccountPageProps {
  onClose: () => void
  user: UserType
  onLogout: () => void
}

export function AccountPage({ onClose, user, onLogout }: AccountPageProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editedUser, setEditedUser] = useState({
    name: user.name,
    email: user.email,
  })
  const [activeTab, setActiveTab] = useState("profile")

  // 2FA states
  const [is2FAEnabled, setIs2FAEnabled] = useState(false)
  const [is2FASetupOpen, setIs2FASetupOpen] = useState(false)
  const [verificationCode, setVerificationCode] = useState("")
  const [qrCodeUrl] = useState("/placeholder.svg?height=200&width=200") // In a real app, this would be generated

  // Activity log data - this would come from the API in a real app
  const activityLog = [
    { id: 1, action: "Logged in", timestamp: new Date().toLocaleString(), ip: "192.168.1.1" },
    {
      id: 2,
      action: "Viewed cargo items",
      timestamp: new Date(Date.now() - 3600000).toLocaleString(),
      ip: "192.168.1.1",
    },
  ]

  // Handle save profile - would call API in a real app
  const handleSaveProfile = () => {
    // In a real app, this would call an API to update the user profile
    setIsEditing(false)
  }

  // Handle 2FA setup
  const handle2FASetup = () => {
    setIs2FASetupOpen(true)
  }

  // Handle 2FA verification
  const handle2FAVerification = () => {
    // In a real app, this would verify the code with the server
    if (verificationCode.length === 6) {
      setIs2FAEnabled(true)
      setIs2FASetupOpen(false)
    }
  }

  // Handle 2FA disable
  const handle2FADisable = () => {
    // In a real app, this would disable 2FA on the server
    setIs2FAEnabled(false)
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="bg-[#000080] text-white p-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <button onClick={onClose} className="text-white hover:text-gray-200">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h2 className="text-xl font-bold">Account Settings</h2>
          </div>
          <button onClick={onLogout} className="flex items-center gap-2 text-white hover:text-gray-200">
            <LogOut className="h-4 w-4" />
            <span>Sign Out</span>
          </button>
        </div>

        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-64 bg-gray-50 p-4 border-r">
            <div className="flex flex-col items-center mb-6">
              <div className="h-20 w-20 rounded-full bg-[#FF9933] flex items-center justify-center text-white text-2xl font-bold mb-2">
                {user.name.charAt(0)}
              </div>
              <div className="text-center">
                <div className="font-bold">{user.name}</div>
                <div className="text-sm text-gray-500">{user.email}</div>
                <div className="mt-1 px-2 py-1 text-xs rounded-full bg-red-100 text-red-800 inline-block">
                  {user.role}
                </div>
              </div>
            </div>

            <nav>
              <button
                onClick={() => setActiveTab("profile")}
                className={`flex items-center gap-2 w-full p-2 rounded-md mb-1 text-left ${
                  activeTab === "profile" ? "bg-[#138808] text-white" : "hover:bg-gray-200"
                }`}
              >
                <User className="h-4 w-4" />
                Profile
              </button>
              <button
                onClick={() => setActiveTab("security")}
                className={`flex items-center gap-2 w-full p-2 rounded-md mb-1 text-left ${
                  activeTab === "security" ? "bg-[#138808] text-white" : "hover:bg-gray-200"
                }`}
              >
                <Key className="h-4 w-4" />
                Security
              </button>
              <button
                onClick={() => setActiveTab("activity")}
                className={`flex items-center gap-2 w-full p-2 rounded-md mb-1 text-left ${
                  activeTab === "activity" ? "bg-[#138808] text-white" : "hover:bg-gray-200"
                }`}
              >
                <Clock className="h-4 w-4" />
                Activity Log
              </button>
            </nav>
          </div>

          <div className="flex-1 p-6">
            {activeTab === "profile" && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-bold">Profile Information</h3>
                  {!isEditing ? (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="px-4 py-2 bg-[#FF9933] text-white rounded-md hover:bg-[#FF9933]/90"
                    >
                      Edit Profile
                    </button>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setIsEditing(false)
                          setEditedUser({
                            name: user.name,
                            email: user.email,
                          })
                        }}
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSaveProfile}
                        className="px-4 py-2 bg-[#138808] text-white rounded-md hover:bg-[#138808]/90"
                      >
                        Save Changes
                      </button>
                    </div>
                  )}
                </div>

                {isEditing ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                      <input
                        type="text"
                        value={editedUser.name}
                        onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                        className="w-full p-2 border rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <input
                        type="email"
                        value={editedUser.email}
                        onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                        className="w-full p-2 border rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                      <input
                        type="text"
                        value={user.role}
                        disabled
                        className="w-full p-2 border rounded-md bg-gray-100"
                      />
                      <p className="text-xs text-gray-500 mt-1">Role can only be changed by an administrator</p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-gray-50 rounded-md p-4 border">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Full Name</div>
                        <div className="font-medium">{user.name}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Email</div>
                        <div className="font-medium">{user.email}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Role</div>
                        <div className="font-medium capitalize">{user.role}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">User ID</div>
                        <div className="font-medium">{user.id}</div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-6">
                  <h3 className="text-lg font-bold mb-4">Permissions</h3>
                  <div className="bg-gray-50 rounded-md p-4 border">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-500" />
                        <span>View Cargo Items</span>
                      </div>
                      {user.role !== "readonly" && (
                        <>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Add Cargo Items</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Edit Cargo Items</span>
                          </div>
                        </>
                      )}
                      {user.role === "admin" && (
                        <>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Delete Cargo Items</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Manage Users</span>
                          </div>
                        </>
                      )}
                      {user.role === "Rakesh Sharma" && (
                        <>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Delete Cargo Items</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-green-500" />
                            <span>Manage Users</span>
                          </div>
                        </>
                      )}
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-500" />
                        <span>View Reports</span>
                      </div>
                      {user.role !== "readonly" && (
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4 text-green-500" />
                          <span>Waste Management</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-500" />
                        <span>3D Visualization</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "security" && (
              <div>
                <h3 className="text-lg font-bold mb-6">Security Settings</h3>

                <div className="bg-gray-50 rounded-md p-4 border mb-6">
                  <h4 className="font-medium mb-4">Change Password</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                      <input type="password" className="w-full p-2 border rounded-md" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                      <input type="password" className="w-full p-2 border rounded-md" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                      <input type="password" className="w-full p-2 border rounded-md" />
                    </div>
                    <button className="px-4 py-2 bg-[#FF9933] text-white rounded-md hover:bg-[#FF9933]/90">
                      Update Password
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-md p-4 border">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h4 className="font-medium">Two-Factor Authentication</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        Add an extra layer of security to your account by enabling two-factor authentication.
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {is2FAEnabled ? (
                        <>
                          <span className="text-green-600 flex items-center gap-1">
                            <Check className="h-4 w-4" /> Enabled
                          </span>
                          <button
                            onClick={handle2FADisable}
                            className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                          >
                            Disable
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={handle2FASetup}
                          className="px-4 py-2 bg-[#138808] text-white rounded-md hover:bg-[#138808]/90"
                        >
                          Enable 2FA
                        </button>
                      )}
                    </div>
                  </div>

                  {is2FASetupOpen && !is2FAEnabled && (
                    <div className="mt-4 border-t pt-4">
                      <h5 className="font-medium mb-2">Setup Two-Factor Authentication</h5>
                      <div className="mb-4">
                        <p className="text-sm mb-2">1. Scan this QR code with your authenticator app:</p>
                        <div className="bg-white p-4 inline-block rounded">
                          <img src={qrCodeUrl || "/placeholder.svg"} alt="2FA QR Code" className="w-40 h-40" />
                        </div>
                      </div>
                      <div className="mb-4">
                        <p className="text-sm mb-2">2. Enter the verification code from your app:</p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={verificationCode}
                            onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                            placeholder="000000"
                            className="w-32 p-2 border rounded-md text-center tracking-widest"
                            maxLength={6}
                          />
                          <button
                            onClick={handle2FAVerification}
                            disabled={verificationCode.length !== 6}
                            className={`px-4 py-2 rounded-md ${
                              verificationCode.length === 6
                                ? "bg-[#138808] text-white hover:bg-[#138808]/90"
                                : "bg-gray-200 text-gray-500 cursor-not-allowed"
                            }`}
                          >
                            Verify
                          </button>
                          <button
                            onClick={() => setIs2FASetupOpen(false)}
                            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p className="font-medium mb-1">Backup codes:</p>
                        <p>If you lose access to your authenticator app, you can use these backup codes to sign in:</p>
                        <div className="bg-gray-100 p-2 rounded mt-2 font-mono text-xs">
                          ABCD-1234-EFGH-5678
                          <br />
                          IJKL-9012-MNOP-3456
                          <br />
                          QRST-7890-UVWX-1234
                          <br />
                        </div>
                        <p className="mt-2 text-red-600">Save these codes in a secure place!</p>
                      </div>
                    </div>
                  )}

                  {is2FAEnabled && (
                    <div className="mt-4 border-t pt-4">
                      <div className="flex items-center gap-2 text-green-600 mb-2">
                        <Check className="h-5 w-5" />
                        <span className="font-medium">Your account is protected with two-factor authentication</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        You'll need to enter a verification code from your authenticator app whenever you sign in.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === "activity" && (
              <div>
                <h3 className="text-lg font-bold mb-6">Activity Log</h3>

                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Action
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Timestamp
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          IP Address
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {activityLog.map((log) => (
                        <tr key={log.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{log.action}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.timestamp}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.ip}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

