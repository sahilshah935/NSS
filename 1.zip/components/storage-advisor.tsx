"use client"

import { useState, useEffect } from "react"
import { Lightbulb, ArrowRight, RotateCcw, Trash2, PackageCheck, Clock, AlertTriangle } from "lucide-react"
import type { CargoItem, Container } from "@/types"

interface StorageAdvisorProps {
  cargoItems: CargoItem[]
  containers: Container[]
  onItemMove: (itemId: string, containerId: string) => void
}

interface CSVItem {
  item_id: string
  name: string
  width_cm: number
  depth_cm: number
  height_cm: number
  mass_kg: number
  priority: number
  expiry_date: string
  usage_limit: number
  preferred_zone: string
}

interface CSVContainer {
  zone: string
  container_id: string
  width_cm: number
  depth_cm: number
  height_cm: number
}

export function StorageAdvisor({ cargoItems, containers, onItemMove }: StorageAdvisorProps) {
  const [selectedRecommendation, setSelectedRecommendation] = useState<string | null>(null)
  const [showDetails, setShowDetails] = useState<string | null>(null)
  const [csvItems, setCsvItems] = useState<CSVItem[]>([])
  const [csvContainers, setCsvContainers] = useState<CSVContainer[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Fetch CSV data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Fetch containers.csv
        const containersResponse = await fetch(
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/containers-CUg03GUyPSlNXkH160YYNdl9nM599Y.csv",
        )

        if (!containersResponse.ok) {
          throw new Error(`Failed to fetch containers: ${containersResponse.status}`)
        }

        const containersText = await containersResponse.text()

        // Parse CSV
        const containersData = parseCSV(containersText)
        setCsvContainers(
          containersData.map((row) => ({
            zone: row.zone || "Unknown",
            container_id: row.container_id || `unknown-${Math.random().toString(36).substring(7)}`,
            width_cm: Number.parseFloat(row.width_cm) || 100,
            depth_cm: Number.parseFloat(row.depth_cm) || 100,
            height_cm: Number.parseFloat(row.height_cm) || 100,
          })),
        )

        // Fetch items.csv
        const itemsResponse = await fetch(
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/input_items-qMn72JrluVK9QW89zRC9qvZCkYGrEA.csv",
        )

        if (!itemsResponse.ok) {
          throw new Error(`Failed to fetch items: ${itemsResponse.status}`)
        }

        const itemsText = await itemsResponse.text()

        // Parse CSV
        const itemsData = parseCSV(itemsText)
        setCsvItems(
          itemsData.map((row) => ({
            item_id: row.item_id || `unknown-${Math.random().toString(36).substring(7)}`,
            name: row.name || "Unknown Item",
            width_cm: Number.parseFloat(row.width_cm) || 10,
            depth_cm: Number.parseFloat(row.depth_cm) || 10,
            height_cm: Number.parseFloat(row.height_cm) || 10,
            mass_kg: Number.parseFloat(row.mass_kg) || 1,
            priority: Number.parseInt(row.priority) || 50,
            expiry_date: row.expiry_date || "N/A",
            usage_limit: Number.parseInt(row.usage_limit) || 100,
            preferred_zone: row.preferred_zone || "Storage_Bay",
          })),
        )
      } catch (error) {
        console.error("Error fetching CSV data:", error)
        // Set default empty arrays to prevent further errors
        setCsvContainers([])
        setCsvItems([])
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  // Parse CSV helper function
  function parseCSV(text: string) {
    try {
      const lines = text.split("\n")
      if (lines.length < 2) return []

      const headers = lines[0].split(",").map((header) => header.trim())
      if (headers.length === 0) return []

      return lines
        .slice(1)
        .filter((line) => line.trim() !== "")
        .map((line) => {
          const values = line.split(",")
          return headers.reduce((obj, header, i) => {
            obj[header] = values[i] ? values[i].trim() : ""
            return obj
          }, {} as any)
        })
    } catch (error) {
      console.error("Error parsing CSV:", error)
      return []
    }
  }

  // Generate placement recommendations
  const placementRecommendations = generatePlacementRecommendations(cargoItems, containers, csvItems, csvContainers)

  // Generate retrieval recommendations
  const retrievalRecommendations = generateRetrievalRecommendations(cargoItems, containers, csvItems)

  // Generate rearrangement recommendations
  const rearrangementRecommendations = generateRearrangementRecommendations(containers, csvContainers)

  // Generate waste disposal recommendations
  const wasteRecommendations = generateWasteRecommendations(cargoItems, containers, csvItems)

  // Generate cargo return recommendations
  const returnRecommendations = generateReturnRecommendations(cargoItems, containers, csvItems)

  // Handle recommendation action
  const handleRecommendationAction = (recommendation: any) => {
    try {
      // In a real app, this would execute the recommendation
      console.log("Executing recommendation:", recommendation)

      // If the recommendation involves moving an item
      if (recommendation.type === "move" && recommendation.itemId && recommendation.targetContainerId) {
        onItemMove(recommendation.itemId, recommendation.targetContainerId)
      } else if (
        recommendation.type === "rearrange" &&
        recommendation.sourceContainerId &&
        recommendation.targetContainerId
      ) {
        // Handle rearrangement logic
        console.log(`Rearranging items from ${recommendation.sourceContainerId} to ${recommendation.targetContainerId}`)
        // In a real app, you would implement the rearrangement logic here
      } else if (recommendation.type === "waste" && recommendation.itemIds && recommendation.targetContainerId) {
        // Handle waste disposal logic
        console.log(`Moving waste items to ${recommendation.targetContainerId}`)
        // In a real app, you would implement the waste disposal logic here
      } else if (recommendation.type === "return" && recommendation.itemIds && recommendation.targetContainerId) {
        // Handle return logic
        console.log(`Preparing items for return in ${recommendation.targetContainerId}`)
        // In a real app, you would implement the return logic here
      }
    } catch (error) {
      console.error("Error executing recommendation:", error)
      alert("Failed to execute recommendation. Please try again.")
    }
  }

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="bg-white rounded-lg shadow p-4">
          <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Lightbulb className="h-6 w-6 text-[#FF9933]" />
            Storage Advisor
          </h1>
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF9933]"></div>
            <span className="ml-3 text-lg">Loading storage data...</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow p-4">
        <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Lightbulb className="h-6 w-6 text-[#FF9933]" />
          Storage Advisor
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Placement Recommendations */}
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <ArrowRight className="h-5 w-5 text-blue-500" />
              Efficient Placement
            </h2>

            {placementRecommendations.length > 0 ? (
              <ul className="space-y-2">
                {placementRecommendations.map((rec, index) => (
                  <li
                    key={index}
                    className="bg-white p-3 rounded-md border border-blue-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-gray-600">{rec.summary}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            showDetails === `placement-${index}`
                              ? setShowDetails(null)
                              : setShowDetails(`placement-${index}`)
                          }
                          className="text-blue-600 hover:text-blue-800 text-sm"
                        >
                          {showDetails === `placement-${index}` ? "Hide Details" : "View Details"}
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec)}
                          className="bg-blue-500 text-white px-2 py-1 rounded-md text-sm hover:bg-blue-600"
                        >
                          Apply
                        </button>
                      </div>
                    </div>

                    {showDetails === `placement-${index}` && (
                      <div className="mt-3 pt-3 border-t text-sm">
                        <p className="font-medium mb-1">Reasoning:</p>
                        <p className="text-gray-600 mb-2">{rec.reasoning}</p>
                        <p className="font-medium mb-1">Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-gray-600">
                          {rec.steps.map((step, stepIndex) => (
                            <li key={stepIndex}>{step}</li>
                          ))}
                        </ol>
                        <div className="mt-2 text-xs text-gray-500">
                          <span className="font-medium">Efficiency Score:</span> {rec.efficiencyScore}/10
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No placement recommendations at this time.</p>
            )}
          </div>

          {/* Retrieval Recommendations */}
          <div className="bg-green-50 border border-green-200 rounded-md p-4">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <PackageCheck className="h-5 w-5 text-green-500" />
              Quick Retrieval
            </h2>

            {retrievalRecommendations.length > 0 ? (
              <ul className="space-y-2">
                {retrievalRecommendations.map((rec, index) => (
                  <li
                    key={index}
                    className="bg-white p-3 rounded-md border border-green-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-gray-600">{rec.summary}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            showDetails === `retrieval-${index}`
                              ? setShowDetails(null)
                              : setShowDetails(`retrieval-${index}`)
                          }
                          className="text-green-600 hover:text-green-800 text-sm"
                        >
                          {showDetails === `retrieval-${index}` ? "Hide Details" : "View Details"}
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec)}
                          className="bg-green-500 text-white px-2 py-1 rounded-md text-sm hover:bg-green-600"
                        >
                          Retrieve
                        </button>
                      </div>
                    </div>

                    {showDetails === `retrieval-${index}` && (
                      <div className="mt-3 pt-3 border-t text-sm">
                        <p className="font-medium mb-1">Location:</p>
                        <p className="text-gray-600 mb-2">{rec.location}</p>
                        <p className="font-medium mb-1">Retrieval Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-gray-600">
                          {rec.steps.map((step, stepIndex) => (
                            <li key={stepIndex}>{step}</li>
                          ))}
                        </ol>
                        <div className="mt-2 text-xs text-gray-500">
                          <span className="font-medium">Estimated Retrieval Time:</span> {rec.retrievalTime} minutes
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No retrieval recommendations at this time.</p>
            )}
          </div>

          {/* Rearrangement Recommendations */}
          <div className="bg-purple-50 border border-purple-200 rounded-md p-4">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-purple-500" />
              Rearrangement Optimization
            </h2>

            {rearrangementRecommendations.length > 0 ? (
              <ul className="space-y-2">
                {rearrangementRecommendations.map((rec, index) => (
                  <li
                    key={index}
                    className="bg-white p-3 rounded-md border border-purple-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-gray-600">{rec.summary}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            showDetails === `rearrangement-${index}`
                              ? setShowDetails(null)
                              : setShowDetails(`rearrangement-${index}`)
                          }
                          className="text-purple-600 hover:text-purple-800 text-sm"
                        >
                          {showDetails === `rearrangement-${index}` ? "Hide Details" : "View Details"}
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec)}
                          className="bg-purple-500 text-white px-2 py-1 rounded-md text-sm hover:bg-purple-600"
                        >
                          Optimize
                        </button>
                      </div>
                    </div>

                    {showDetails === `rearrangement-${index}` && (
                      <div className="mt-3 pt-3 border-t text-sm">
                        <p className="font-medium mb-1">Current Utilization:</p>
                        <p className="text-gray-600 mb-2">{rec.currentUtilization}%</p>
                        <p className="font-medium mb-1">Projected Utilization:</p>
                        <p className="text-gray-600 mb-2">{rec.projectedUtilization}%</p>
                        <p className="font-medium mb-1">Rearrangement Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-gray-600">
                          {rec.steps.map((step, stepIndex) => (
                            <li key={stepIndex}>{step}</li>
                          ))}
                        </ol>
                        <div className="mt-2 text-xs text-gray-500">
                          <span className="font-medium">Space Saved:</span> {rec.spaceSaved} cubic units
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No rearrangement recommendations at this time.</p>
            )}
          </div>

          {/* Waste Disposal Recommendations */}
          <div className="bg-red-50 border border-red-200 rounded-md p-4">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <Trash2 className="h-5 w-5 text-red-500" />
              Waste Disposal Management
            </h2>

            {wasteRecommendations.length > 0 ? (
              <ul className="space-y-2">
                {wasteRecommendations.map((rec, index) => (
                  <li
                    key={index}
                    className="bg-white p-3 rounded-md border border-red-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-gray-600">{rec.summary}</p>
                        {rec.urgency === "high" && (
                          <span className="inline-block mt-1 px-2 py-0.5 bg-red-100 text-red-800 text-xs rounded-full">
                            Urgent
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            showDetails === `waste-${index}` ? setShowDetails(null) : setShowDetails(`waste-${index}`)
                          }
                          className="text-red-600 hover:text-red-800 text-sm"
                        >
                          {showDetails === `waste-${index}` ? "Hide Details" : "View Details"}
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec)}
                          className="bg-red-500 text-white px-2 py-1 rounded-md text-sm hover:bg-red-600"
                        >
                          Process
                        </button>
                      </div>
                    </div>

                    {showDetails === `waste-${index}` && (
                      <div className="mt-3 pt-3 border-t text-sm">
                        <p className="font-medium mb-1">Items to Process:</p>
                        <ul className="list-disc list-inside space-y-1 text-gray-600">
                          {rec.items.map((item, itemIndex) => (
                            <li key={itemIndex}>{item}</li>
                          ))}
                        </ul>
                        <p className="font-medium mt-2 mb-1">Disposal Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-gray-600">
                          {rec.steps.map((step, stepIndex) => (
                            <li key={stepIndex}>{step}</li>
                          ))}
                        </ol>
                        <div className="mt-2 text-xs text-gray-500">
                          <span className="font-medium">Space Reclaimed:</span> {rec.spaceReclaimed} cubic units
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No waste disposal recommendations at this time.</p>
            )}
          </div>

          {/* Cargo Return Planning */}
          <div className="md:col-span-2 bg-amber-50 border border-amber-200 rounded-md p-4">
            <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
              <Clock className="h-5 w-5 text-amber-500" />
              Cargo Return Planning
            </h2>

            {returnRecommendations.length > 0 ? (
              <ul className="space-y-2">
                {returnRecommendations.map((rec, index) => (
                  <li
                    key={index}
                    className="bg-white p-3 rounded-md border border-amber-100 hover:shadow-md transition-shadow"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{rec.title}</h3>
                        <p className="text-sm text-gray-600">{rec.summary}</p>
                        <div className="mt-1">
                          <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-800 text-xs rounded-full">
                            Next undocking: {rec.undockingDate}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            showDetails === `return-${index}` ? setShowDetails(null) : setShowDetails(`return-${index}`)
                          }
                          className="text-amber-600 hover:text-amber-800 text-sm"
                        >
                          {showDetails === `return-${index}` ? "Hide Details" : "View Details"}
                        </button>
                        <button
                          onClick={() => handleRecommendationAction(rec)}
                          className="bg-amber-500 text-white px-2 py-1 rounded-md text-sm hover:bg-amber-600"
                        >
                          Prepare
                        </button>
                      </div>
                    </div>

                    {showDetails === `return-${index}` && (
                      <div className="mt-3 pt-3 border-t text-sm">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p className="font-medium mb-1">Items to Return:</p>
                            <ul className="list-disc list-inside space-y-1 text-gray-600">
                              {rec.itemsToReturn.map((item, itemIndex) => (
                                <li key={itemIndex}>{item}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-medium mb-1">Waste to Return:</p>
                            <ul className="list-disc list-inside space-y-1 text-gray-600">
                              {rec.wasteToReturn.map((item, itemIndex) => (
                                <li key={itemIndex}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <p className="font-medium mt-2 mb-1">Preparation Steps:</p>
                        <ol className="list-decimal list-inside space-y-1 text-gray-600">
                          {rec.steps.map((step, stepIndex) => (
                            <li key={stepIndex}>{step}</li>
                          ))}
                        </ol>
                        <div className="mt-2 text-xs text-gray-500">
                          <span className="font-medium">Total Return Weight:</span> {rec.totalWeight} kg
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No cargo return recommendations at this time.</p>
            )}
          </div>
        </div>

        {/* Activity Log */}
        <div className="mt-6">
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-gray-500" />
            Recent Activity Log
          </h2>

          <div className="border rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Action
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Item/Container
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Details
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {getRecentActivityLogs().map((log, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{log.action}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.user}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.target}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.timestamp}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

// Helper functions to generate recommendations
function generatePlacementRecommendations(
  cargoItems: CargoItem[],
  containers: Container[],
  csvItems: any[],
  csvContainers: any[],
) {
  // Use CSV data to enhance recommendations
  const unassignedItems = cargoItems.filter((item) => !item.containerId)

  if (unassignedItems.length === 0) {
    // Use CSV data to suggest placement for new items
    const newItems = csvItems.slice(0, 3) // Take first 3 items from CSV as examples

    return newItems.map((csvItem, index) => {
      const preferredZone = csvItem.preferred_zone
      const matchingContainers = csvContainers.filter((c) => c.zone === preferredZone)
      const bestContainer = matchingContainers.length > 0 ? matchingContainers[0] : csvContainers[0]

      // Find a matching container in our system
      const systemContainer =
        containers.find(
          (c) =>
            c.name.toLowerCase().includes(bestContainer.zone.toLowerCase()) ||
            c.section.toLowerCase().includes(bestContainer.zone.toLowerCase()),
        ) || containers[0]

      return {
        title: `Place ${csvItem.name.replace("_", " ")} in ${systemContainer.name}`,
        summary: `Recommended placement for new ${csvItem.name.replace("_", " ")} item.`,
        reasoning: `${systemContainer.name} is in the ${preferredZone} zone which is the preferred location for this item type. The container has adequate space and dimensions (${bestContainer.width_cm}cm × ${bestContainer.depth_cm}cm × ${bestContainer.height_cm}cm) to accommodate this item.`,
        steps: [
          `Receive ${csvItem.name.replace("_", " ")} from supply shipment`,
          `Move to ${systemContainer.section} section`,
          `Place in ${systemContainer.name} on the ${getRecommendedPosition(csvItem)} shelf`,
          `Update inventory system to record new location`,
        ],
        efficiencyScore: 9,
        type: "move",
        itemId: `csv-${csvItem.item_id}`,
        targetContainerId: systemContainer.id,
      }
    })
  }

  // Generate recommendations for existing unassigned items
  return unassignedItems.map((item) => {
    // Find matching CSV item for enhanced data
    const csvItem = csvItems.find((i) => i.name.toLowerCase().includes(item.name.toLowerCase()))
    const preferredZone = csvItem ? csvItem.preferred_zone : "Storage_Bay"

    // Find best container based on category matching and available space
    const bestContainer = findBestContainerForItem(item, containers, preferredZone)

    return {
      title: `Place ${item.name} in ${bestContainer.name}`,
      summary: `Recommended placement for ${item.category} item.`,
      reasoning: `${bestContainer.name} has adequate space and already contains similar ${item.category} items, making retrieval more efficient. ${csvItem ? `This item is preferred to be stored in the ${preferredZone} zone.` : ""}`,
      steps: [
        `Take ${item.name} from temporary storage`,
        `Move to ${bestContainer.section} section`,
        `Place in ${bestContainer.name} on the ${item.position || getRecommendedPosition(csvItem || item)} shelf`,
        `Update inventory system to record new location`,
      ],
      efficiencyScore: 9,
      type: "move",
      itemId: item.id,
      targetContainerId: bestContainer.id,
    }
  })
}

function generateRetrievalRecommendations(cargoItems: CargoItem[], containers: Container[], csvItems: any[]) {
  // Find items that are expiring soon
  const now = new Date()
  const thirtyDaysFromNow = new Date()
  thirtyDaysFromNow.setDate(now.getDate() + 30)

  const expiringItems = cargoItems.filter((item) => {
    if (!item.expiryDate) return false
    const expiryDate = new Date(item.expiryDate)
    return expiryDate > now && expiryDate <= thirtyDaysFromNow
  })

  // If no expiring items in the system, use CSV data to suggest retrievals
  if (expiringItems.length === 0) {
    // Find items in CSV that have expiry dates
    const csvExpiringItems = csvItems
      .filter(
        (item) => item.expiry_date && item.expiry_date !== "N/A" && new Date(item.expiry_date) <= thirtyDaysFromNow,
      )
      .slice(0, 3) // Take top 3

    if (csvExpiringItems.length === 0) {
      return [
        {
          title: "No urgent retrievals needed",
          summary: "No items expiring soon or requiring immediate attention.",
          location: "N/A",
          steps: ["Continue regular inventory checks"],
          retrievalTime: 0,
          type: "info",
        },
      ]
    }

    return csvExpiringItems.map((item) => {
      const container =
        containers.find((c) => c.section.toLowerCase().includes(item.preferred_zone.toLowerCase())) || containers[0]

      return {
        title: `Retrieve ${item.name.replace("_", " ")} (Expires Soon)`,
        summary: `This item expires on ${item.expiry_date}`,
        location: `${container.name} in ${container.section} section`,
        steps: generateRetrievalSteps(null, container, item),
        retrievalTime: calculateRetrievalTime(null, container),
        type: "retrieve",
        itemId: `csv-${item.item_id}`,
      }
    })
  }

  // Sort by expiry date (closest first)
  expiringItems.sort((a, b) => {
    const dateA = new Date(a.expiryDate || "")
    const dateB = new Date(b.expiryDate || "")
    return dateA.getTime() - dateB.getTime()
  })

  // Generate recommendations for the top 3 most urgent items
  return expiringItems.slice(0, 3).map((item) => {
    const container = containers.find((c) => c.id === item.containerId)

    return {
      title: `Retrieve ${item.name} (Expires Soon)`,
      summary: `This ${item.category} item expires on ${item.expiryDate}`,
      location: container ? `${container.name} in ${container.section} section` : "Unassigned",
      steps: generateRetrievalSteps(item, container),
      retrievalTime: calculateRetrievalTime(item, container),
      type: "retrieve",
      itemId: item.id,
    }
  })
}

function generateRearrangementRecommendations(containers: Container[], csvContainers: any[]) {
  // Find containers that are nearly full
  const nearlyFullContainers = containers.filter((container) => {
    const utilizationPercentage = (container.items.length / container.capacity) * 100
    return utilizationPercentage > 80
  })

  if (nearlyFullContainers.length === 0) {
    // Use CSV data to suggest optimizations
    const zones = [...new Set(csvContainers.map((c) => c.zone))]

    // If no zones or containers available, return a default recommendation
    if (zones.length === 0 || containers.length < 2) {
      return [
        {
          title: "No rearrangement needed",
          summary: "Current storage utilization is optimal.",
          currentUtilization: calculateOverallUtilization(containers),
          projectedUtilization: calculateOverallUtilization(containers),
          steps: ["Continue monitoring storage levels"],
          spaceSaved: 0,
          type: "info",
        },
      ]
    }

    const zoneUtilization = zones.map((zone) => {
      const zoneContainers = csvContainers.filter((c) => c.zone === zone)
      const totalVolume = zoneContainers.reduce((sum, c) => sum + c.width_cm * c.depth_cm * c.height_cm, 0)
      return { zone, totalVolume }
    })

    // Make sure we have at least two zones to compare
    if (zoneUtilization.length < 2) {
      return [
        {
          title: "No rearrangement needed",
          summary: "Current storage utilization is optimal.",
          currentUtilization: calculateOverallUtilization(containers),
          projectedUtilization: calculateOverallUtilization(containers),
          steps: ["Continue monitoring storage levels"],
          spaceSaved: 0,
          type: "info",
        },
      ]
    }

    // Find most and least utilized zones
    zoneUtilization.sort((a, b) => b.totalVolume - a.totalVolume)
    const mostUtilizedZone = zoneUtilization[0]
    const leastUtilizedZone = zoneUtilization[zoneUtilization.length - 1]

    // Find corresponding containers in our system
    // Safely access container sections
    const sourceContainer =
      containers.find(
        (c) => mostUtilizedZone && c.section.toLowerCase().includes(mostUtilizedZone.zone.toLowerCase()),
      ) || containers[0]

    // Make sure we don't select the same container
    const targetContainer =
      containers.find(
        (c) =>
          leastUtilizedZone &&
          c.section.toLowerCase().includes(leastUtilizedZone.zone.toLowerCase()) &&
          c.id !== sourceContainer.id,
      ) ||
      containers.find((c) => c.id !== sourceContainer.id) ||
      containers[1]

    return [
      {
        title: `Balance load between ${sourceContainer.name} and ${targetContainer.name}`,
        summary: `Optimize storage by redistributing items between containers`,
        currentUtilization: 85, // Estimated
        projectedUtilization: 70, // Estimated after rearrangement
        steps: [
          `Identify non-essential items in ${sourceContainer.name}`,
          `Move selected items to ${targetContainer.name}`,
          `Reorganize ${sourceContainer.name} by priority`,
          `Update inventory system with new locations`,
        ],
        spaceSaved: Math.floor(sourceContainer.capacity * 0.15), // Estimated 15% improvement
        type: "rearrange",
        sourceContainerId: sourceContainer.id,
        targetContainerId: targetContainer.id,
      },
    ]
  }

  // Find containers with available space
  const containersWithSpace = containers.filter((container) => {
    const utilizationPercentage = (container.items.length / container.capacity) * 100
    return utilizationPercentage < 50
  })

  if (containersWithSpace.length === 0) {
    return [
      {
        title: "Critical: Space optimization needed",
        summary: "Multiple containers are near capacity with no available space.",
        currentUtilization: calculateOverallUtilization(containers),
        projectedUtilization: calculateOverallUtilization(containers) - 5, // Estimated improvement
        steps: ["Request priority waste disposal", "Consolidate similar items", "Consider emergency storage expansion"],
        spaceSaved: 10, // Estimated cubic units
        type: "critical",
      },
    ]
  }

  // Generate recommendations
  return nearlyFullContainers.map((fullContainer) => {
    const targetContainer = containersWithSpace[0] // Simplistic for demo

    return {
      title: `Optimize ${fullContainer.name} space`,
      summary: `Rearrange items from ${fullContainer.name} to ${targetContainer.name}`,
      currentUtilization: calculateContainerUtilization(fullContainer),
      projectedUtilization: 70, // Estimated after rearrangement
      steps: [
        `Move low-priority items from ${fullContainer.name} to ${targetContainer.name}`,
        `Consolidate similar items in ${fullContainer.name}`,
        `Reorganize ${fullContainer.name} by priority`,
      ],
      spaceSaved: Math.floor(fullContainer.capacity * 0.2), // Estimated 20% improvement
      type: "rearrange",
      sourceContainerId: fullContainer.id,
      targetContainerId: targetContainer.id,
    }
  })
}

function generateWasteRecommendations(cargoItems: CargoItem[], containers: Container[], csvItems: any[]) {
  // Find expired items
  const now = new Date()
  const expiredItems = cargoItems.filter((item) => {
    if (!item.expiryDate) return false
    return new Date(item.expiryDate) < now
  })

  // If no expired items in the system, use CSV data
  if (expiredItems.length === 0) {
    // Find items in CSV that have expiry dates and are expired
    const csvExpiredItems = csvItems
      .filter((item) => item.expiry_date && item.expiry_date !== "N/A" && new Date(item.expiry_date) < now)
      .slice(0, 5) // Take top 5

    if (csvExpiredItems.length === 0) {
      // Find items with high usage that might be waste
      const highUsageItems = csvItems.filter((item) => item.usage_limit > 0 && item.usage_limit < 10).slice(0, 3)

      if (highUsageItems.length === 0) {
        return [
          {
            title: "No waste processing needed",
            summary: "No expired or waste items detected.",
            urgency: "low",
            items: [],
            steps: ["Continue regular waste monitoring"],
            spaceReclaimed: 0,
            type: "info",
          },
        ]
      }

      // Find waste container
      const wasteContainer = containers.find((container) => container.name.toLowerCase().includes("waste"))

      if (!wasteContainer) {
        return [
          {
            title: "Waste container not found",
            summary: "System cannot locate designated waste container.",
            urgency: "high",
            items: highUsageItems.map((item) => `${item.name.replace("_", " ")} (near usage limit)`),
            steps: [
              "Designate a temporary waste storage area",
              "Contact mission control for waste handling instructions",
              "Manually tag items in system",
            ],
            spaceReclaimed: highUsageItems.reduce(
              (sum, item) => sum + (item.width_cm * item.depth_cm * item.height_cm) / 1000,
              0,
            ),
            type: "error",
          },
        ]
      }

      return [
        {
          title: `Process ${highUsageItems.length} items near usage limit`,
          summary: `Move items approaching usage limit to waste container.`,
          urgency: "medium",
          items: highUsageItems.map((item) => `${item.name.replace("_", " ")} (${item.usage_limit} uses remaining)`),
          steps: [
            "Collect all items approaching usage limit",
            `Move items to ${wasteContainer.name} in ${wasteContainer.section} section`,
            "Log disposal reason for each item",
            "Update inventory system",
          ],
          spaceReclaimed: highUsageItems.reduce(
            (sum, item) => sum + (item.width_cm * item.depth_cm * item.height_cm) / 1000,
            0,
          ),
          type: "waste",
          itemIds: highUsageItems.map((item) => `csv-${item.item_id}`),
          targetContainerId: wasteContainer.id,
        },
      ]
    }

    // Find waste container
    const wasteContainer = containers.find((container) => container.name.toLowerCase().includes("waste"))

    if (!wasteContainer) {
      return [
        {
          title: "Waste container not found",
          summary: "System cannot locate designated waste container.",
          urgency: "high",
          items: csvExpiredItems.map((item) => `${item.name.replace("_", " ")} (expired on ${item.expiry_date})`),
          steps: [
            "Designate a temporary waste storage area",
            "Contact mission control for waste handling instructions",
            "Manually tag expired items in system",
          ],
          spaceReclaimed: csvExpiredItems.reduce(
            (sum, item) => sum + (item.width_cm * item.depth_cm * item.height_cm) / 1000,
            0,
          ),
          type: "error",
        },
      ]
    }

    return [
      {
        title: `Process ${csvExpiredItems.length} expired items`,
        summary: `Move expired items to waste container for disposal.`,
        urgency: csvExpiredItems.length > 3 ? "high" : "medium",
        items: csvExpiredItems.map((item) => `${item.name.replace("_", " ")} (expired on ${item.expiry_date})`),
        steps: [
          "Collect all expired items from their current locations",
          `Move items to ${wasteContainer.name} in ${wasteContainer.section} section`,
          "Log disposal reason for each item",
          "Update inventory system",
        ],
        spaceReclaimed: csvExpiredItems.reduce(
          (sum, item) => sum + (item.width_cm * item.depth_cm * item.height_cm) / 1000,
          0,
        ),
        type: "waste",
        itemIds: csvExpiredItems.map((item) => `csv-${item.item_id}`),
        targetContainerId: wasteContainer.id,
      },
    ]
  }

  // Find waste container
  const wasteContainer = containers.find((container) => container.name.toLowerCase().includes("waste"))

  if (!wasteContainer) {
    return [
      {
        title: "Waste container not found",
        summary: "System cannot locate designated waste container.",
        urgency: "high",
        items: expiredItems.map((item) => `${item.name} (${item.category})`),
        steps: [
          "Designate a temporary waste storage area",
          "Contact mission control for waste handling instructions",
          "Manually tag expired items in system",
        ],
        spaceReclaimed: calculateTotalItemsVolume(expiredItems),
        type: "error",
      },
    ]
  }

  return [
    {
      title: `Process ${expiredItems.length} expired items`,
      summary: `Move expired items to waste container for disposal.`,
      urgency: expiredItems.length > 5 ? "high" : "medium",
      items: expiredItems.map((item) => `${item.name} (${item.category})`),
      steps: [
        "Collect all expired items from their current locations",
        `Move items to ${wasteContainer.name} in ${wasteContainer.section} section`,
        "Log disposal reason for each item",
        "Update inventory system",
      ],
      spaceReclaimed: calculateTotalItemsVolume(expiredItems),
      type: "waste",
      itemIds: expiredItems.map((item) => item.id),
      targetContainerId: wasteContainer.id,
    },
  ]
}

function generateReturnRecommendations(cargoItems: CargoItem[], containers: Container[], csvItems: any[]) {
  // Find return container
  const returnContainer = containers.find((container) => container.name.toLowerCase().includes("return"))

  if (!returnContainer) {
    return [
      {
        title: "Return container not configured",
        summary: "System cannot locate designated return container.",
        undockingDate: "Unknown",
        itemsToReturn: [],
        wasteToReturn: [],
        steps: [
          "Designate a temporary return storage area",
          "Contact mission control for return cargo instructions",
          "Manually tag items for return in system",
        ],
        totalWeight: 0,
        type: "error",
      },
    ]
  }

  // Find waste items for return
  const wasteContainer = containers.find((container) => container.name.toLowerCase().includes("waste"))
  const wasteItems = wasteContainer ? wasteContainer.items : []

  // Find items that need to be returned (used equipment, experiments, etc.)
  const itemsForReturn = cargoItems.filter(
    (item) => item.category.toLowerCase().includes("equipment") && item.name.toLowerCase().includes("used"),
  )

  // If no items for return in the system, use CSV data
  if (itemsForReturn.length === 0 && wasteItems.length === 0) {
    // Find equipment items in CSV that might need to be returned
    const csvReturnItems = csvItems
      .filter(
        (item) =>
          item.name.toLowerCase().includes("equipment") ||
          item.name.toLowerCase().includes("sample") ||
          item.name.toLowerCase().includes("experiment"),
      )
      .slice(0, 5) // Take top 5

    // Generate a simulated undocking date (2 weeks from now)
    const undockingDate = new Date()
    undockingDate.setDate(undockingDate.getDate() + 14)
    const formattedUndockingDate = undockingDate.toISOString().split("T")[0]

    return [
      {
        title: "Prepare for next cargo return",
        summary: `Prepare items for return on ${formattedUndockingDate}.`,
        undockingDate: formattedUndockingDate,
        itemsToReturn: csvReturnItems.map((item) => `${item.name.replace("_", " ")} (${item.mass_kg} kg)`),
        wasteToReturn: [],
        steps: [
          "Collect all items marked for return",
          `Move items to ${returnContainer.name} in ${returnContainer.section} section`,
          "Secure items according to return protocol",
          "Complete return manifest documentation",
          "Verify weight distribution",
        ],
        totalWeight: csvReturnItems.reduce((sum, item) => sum + Number.parseFloat(item.mass_kg), 0),
        type: "return",
        itemIds: csvReturnItems.map((item) => `csv-${item.item_id}`),
        targetContainerId: returnContainer.id,
      },
    ]
  }

  // Generate a simulated undocking date (2 weeks from now)
  const undockingDate = new Date()
  undockingDate.setDate(undockingDate.getDate() + 14)
  const formattedUndockingDate = undockingDate.toISOString().split("T")[0]

  return [
    {
      title: "Prepare for next cargo return",
      summary: `Prepare items for return on ${formattedUndockingDate}.`,
      undockingDate: formattedUndockingDate,
      itemsToReturn: itemsForReturn.map((item) => `${item.name} (${item.category})`),
      wasteToReturn: wasteItems.map((item) => `${item.name} (${item.category})`),
      steps: [
        "Collect all items marked for return",
        `Move items to ${returnContainer.name} in ${returnContainer.section} section`,
        "Secure items according to return protocol",
        "Complete return manifest documentation",
        "Verify weight distribution",
      ],
      totalWeight: calculateTotalWeight(itemsForReturn) + calculateTotalWeight(wasteItems),
      type: "return",
      itemIds: [...itemsForReturn.map((item) => item.id), ...wasteItems.map((item) => item.id)],
      targetContainerId: returnContainer.id,
    },
  ]
}

// Helper functions for recommendation generation
function findBestContainerForItem(item: CargoItem, containers: Container[], preferredZone?: string) {
  // If preferred zone is specified, try to find containers in that zone
  if (preferredZone) {
    const zoneContainers = containers.filter(
      (container) =>
        container.section.toLowerCase().includes(preferredZone.toLowerCase()) &&
        container.items.length < container.capacity,
    )

    if (zoneContainers.length > 0) {
      // Find the one with the most available space
      return zoneContainers.sort((a, b) => a.capacity - a.items.length - (b.capacity - b.items.length))[0]
    }
  }

  // First, try to find containers with the same category items
  const sameCategory = containers.filter(
    (container) =>
      container.items.some((i) => i.category === item.category) && container.items.length < container.capacity,
  )

  if (sameCategory.length > 0) {
    // Find the one with the most available space
    return sameCategory.sort((a, b) => a.capacity - a.items.length - (b.capacity - b.items.length))[0]
  }

  // If no containers with same category, find one with most available space
  return containers
    .filter((container) => container.items.length < container.capacity)
    .sort((a, b) => a.capacity - a.items.length - (b.capacity - b.items.length))[0]
}

function getRecommendedPosition(item: any) {
  // In a real app, this would be more sophisticated
  // For now, we'll use a simple algorithm based on weight or mass
  const weight = item.weight || item.mass_kg || 0

  if (weight < 1) return "top"
  if (weight < 5) return "middle"
  return "bottom"
}

function generateRetrievalSteps(item: CargoItem | null, container: Container | undefined, csvItem?: any) {
  if (!container) {
    return ["Item location unknown", "Check temporary storage areas"]
  }

  if (item) {
    return [
      `Go to ${container.section} section`,
      `Locate ${container.name}`,
      `Open ${container.name} using access code ${container.id.slice(-4)}`,
      `Retrieve ${item.name} from the ${item.position || "unknown"} position`,
      "Scan barcode to update inventory",
      "Close and secure container",
    ]
  } else if (csvItem) {
    return [
      `Go to ${container.section} section`,
      `Locate ${container.name}`,
      `Open ${container.name} using access code ${container.id.slice(-4)}`,
      `Retrieve ${csvItem.name.replace("_", " ")} from the ${getRecommendedPosition(csvItem)} position`,
      "Scan barcode to update inventory",
      "Close and secure container",
    ]
  } else {
    return [
      `Go to ${container.section} section`,
      `Locate ${container.name}`,
      `Open ${container.name} using access code ${container.id.slice(-4)}`,
      "Retrieve item from container",
      "Scan barcode to update inventory",
      "Close and secure container",
    ]
  }
}

function calculateRetrievalTime(item: CargoItem | null, container: Container | undefined) {
  if (!container) return 10 // Unknown location takes longer

  // Base time in minutes
  let time = 2

  // Add time based on section (some sections are further away)
  if (container.section === "Aft") time += 2
  if (container.section === "Lab Module") time += 3

  // Add time based on position
  if (item && item.position === "bottom") time += 1

  return time
}

function calculateOverallUtilization(containers: Container[]) {
  const totalItems = containers.reduce((sum, container) => sum + container.items.length, 0)
  const totalCapacity = containers.reduce((sum, container) => sum + container.capacity, 0)

  return Math.round((totalItems / totalCapacity) * 100)
}

function calculateContainerUtilization(container: Container) {
  return Math.round((container.items.length / container.capacity) * 100)
}

function calculateTotalItemsVolume(items: CargoItem[]) {
  // In a real app, this would use actual volume data
  // For now, we'll estimate based on weight
  return items.reduce((sum, item) => sum + item.weight * 0.5, 0)
}

function calculateTotalWeight(items: CargoItem[]) {
  return items.reduce((sum, item) => sum + item.weight, 0)
}

function getRecentActivityLogs() {
  // In a real app, this would fetch from a database
  // For now, we'll return sample data
  return [
    {
      action: "Moved Item",
      user: "Rakesh Sharma",
      target: "Medical Supplies",
      timestamp: new Date(Date.now() - 3600000).toLocaleString(),
      details: "Moved from Storage Bay A to Science Rack",
    },
    {
      action: "Added Item",
      user: "Kalpana Chawla",
      target: "Food Rations",
      timestamp: new Date(Date.now() - 7200000).toLocaleString(),
      details: "Added 5 units to Food Storage",
    },
    {
      action: "Disposed Item",
      user: "Sunita Williams",
      target: "Expired Medication",
      timestamp: new Date(Date.now() - 10800000).toLocaleString(),
      details: "Moved to Waste Container",
    },
    {
      action: "Retrieved Item",
      user: "Rakesh Sharma",
      target: "Experiment Equipment",
      timestamp: new Date(Date.now() - 14400000).toLocaleString(),
      details: "Retrieved from Science Rack",
    },
    {
      action: "Rearranged Container",
      user: "Rakesh Sharma",
      target: "Storage Bay B",
      timestamp: new Date(Date.now() - 28800000).toLocaleString(),
      details: "Optimized space utilization",
    },
  ]
}

