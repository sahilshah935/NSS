"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/hooks/use-auth"
import { ArrowLeft, AlertCircle, Check, Loader2 } from "lucide-react"
import type { Container, CargoItem } from "@/types"

interface AddCargoItemProps {
  onClose: () => void
  containers: Container[]
  onAddSuccess: (newItem?: CargoItem) => void
}

export function AddCargoItem({ onClose, containers, onAddSuccess }: AddCargoItemProps) {
  const { token } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    item_name: "",
    category_id: "1", // Default to food
    quantity: 1,
    unit_weight: 1,
    expiration_date: "",
    stored_in_unit: "",
  })

  // Categories
  const categories = [
    { id: "1", name: "Food" },
    { id: "2", name: "Medicine" },
    { id: "3", name: "Equipment" },
    { id: "4", name: "Supplies" },
  ]

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const validateForm = () => {
    if (!formData.item_name.trim()) {
      setError("Item name is required")
      return false
    }

    if (!formData.stored_in_unit) {
      setError("Storage container is required")
      return false
    }

    if (formData.quantity < 1) {
      setError("Quantity must be at least 1")
      return false
    }

    if (formData.unit_weight <= 0) {
      setError("Weight must be greater than 0")
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    if (!validateForm()) {
      setIsLoading(false)
      return
    }

    try {
      // Generate a unique ID for the new item
      const newItemId = `item-${Date.now()}`

      // Get category name from ID
      const category = categories.find((c) => c.id === formData.category_id)?.name || "Unknown"

      // Create the new item
      const newItem: CargoItem = {
        id: newItemId,
        name: formData.item_name,
        category: category,
        weight: Number(formData.unit_weight),
        expiryDate: formData.expiration_date || null,
        priority: getPriorityFromCategory(category),
        containerId: formData.stored_in_unit,
        position: getRandomPosition(),
        quantity: Number(formData.quantity),
      }

      // Try to submit to API
      try {
        const response = await fetch("http://localhost:3001/api/cargo-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(formData),
        })

        if (!response.ok) {
          const data = await response.json()
          console.log("Server response error:", data)
        }
      } catch (err) {
        console.log("Server connection failed, adding item in offline mode")
      }

      // Show success message
      setSuccess("Cargo item added successfully!")

      // Clear form
      setFormData({
        item_name: "",
        category_id: "1",
        quantity: 1,
        unit_weight: 1,
        expiration_date: "",
        stored_in_unit: "",
      })

      // Notify parent component
      setTimeout(() => {
        onAddSuccess(newItem)
      }, 1500)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const getPriorityFromCategory = (category: string): "high" | "medium" | "low" => {
    switch (category.toLowerCase()) {
      case "medicine":
      case "food":
        return "high"
      case "equipment":
        return "medium"
      default:
        return "low"
    }
  }

  const getRandomPosition = (): "top" | "middle" | "bottom" => {
    const positions: ("top" | "middle" | "bottom")[] = ["top", "middle", "bottom"]
    return positions[Math.floor(Math.random() * positions.length)]
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <div className="bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="bg-[#FF9933] text-white p-4 flex items-center gap-2">
          <button onClick={onClose} className="text-white hover:text-gray-200">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2 className="text-xl font-bold">Add New Cargo Item</h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 flex items-start">
              <AlertCircle className="h-5 w-5 mr-2 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 flex items-center">
              <Check className="h-5 w-5 mr-2" />
              <span>{success}</span>
            </div>
          )}

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Item Name*</label>
            <input
              type="text"
              name="item_name"
              value={formData.item_name}
              onChange={handleChange}
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category*</label>
              <select
                name="category_id"
                value={formData.category_id}
                onChange={handleChange}
                className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                required
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Storage Container*</label>
              <select
                name="stored_in_unit"
                value={formData.stored_in_unit}
                onChange={handleChange}
                className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                required
              >
                <option value="">Select container</option>
                {containers.map((container) => (
                  <option key={container.id} value={container.id}>
                    {container.name} ({container.section})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Quantity*</label>
              <input
                type="number"
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                min="1"
                className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Weight (kg)*</label>
              <input
                type="number"
                name="unit_weight"
                value={formData.unit_weight}
                onChange={handleChange}
                min="0.1"
                step="0.1"
                className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
                required
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Expiration Date</label>
            <input
              type="date"
              name="expiration_date"
              value={formData.expiration_date}
              onChange={handleChange}
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-[#FF9933] focus:border-[#FF9933]"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
              disabled={isLoading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#138808] text-white rounded-md hover:bg-[#138808]/90"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Adding...
                </span>
              ) : (
                "Add Item"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

