"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter } from "next/navigation"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment } from "@react-three/drei"
import { StorageContainer } from "@/components/storage-container"
import { CargoItem } from "@/components/cargo-item"
import { SearchPanel } from "@/components/search-panel"
import { Dashboard } from "@/components/dashboard"
import { Navigation } from "@/components/navigation"
import { AlertPanel } from "@/components/alert-panel"
import { WasteManagement } from "@/components/waste-management"
import { AccessControl } from "@/components/access-control"
import { AccountPage } from "@/components/account-page"
import { AddCargoItem } from "@/components/add-cargo-item"
import { StorageAdvisor } from "@/components/storage-advisor"
import { useCargoData } from "@/hooks/use-cargo-data"
import { useAuth } from "@/hooks/use-auth"
import { WifiOff, Plus } from "lucide-react"

// Loading component for the 3D view
function CanvasLoader() {
  return (
    <div className="flex h-full items-center justify-center">
      <div className="text-center">
        <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-[#FF9933] border-t-transparent mx-auto"></div>
        <h2 className="text-xl font-semibold">Loading 3D View...</h2>
      </div>
    </div>
  )
}

export default function ISSCargoManagement() {
  const [activeView, setActiveView] = useState("3d-view")
  const [showAccountPage, setShowAccountPage] = useState(false)
  const [showAddCargoModal, setShowAddCargoModal] = useState(false)
  const { user, isLoading: authLoading, logout } = useAuth()
  const {
    cargoItems,
    containers,
    alerts,
    utilization,
    handleItemMove,
    handleItemRemove,
    handleAddItem,
    isLoading: dataLoading,
    error,
    refreshData,
    isOfflineMode,
  } = useCargoData()
  const router = useRouter()

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login")
    }
  }, [authLoading, user, router])

  // Show loading state while checking auth or loading data
  if (authLoading || dataLoading || !user) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#f5f5f5]">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-[#FF9933] border-t-transparent mx-auto"></div>
          <h2 className="text-xl font-semibold">Loading...</h2>
          {error && <p className="mt-2 text-red-500">{error}</p>}
        </div>
      </div>
    )
  }

  // When a modal is open, we'll hide the main content
  const isModalOpen = showAccountPage || showAddCargoModal

  return (
    <div className="flex h-screen flex-col bg-[#f5f5f5]">
      <header className="bg-gradient-to-r from-[#FF9933] to-[#FF9933]/90 p-4 text-white shadow-md">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">ISS Cargo Management System</h1>
          <div className="flex items-center gap-4">
            {isOfflineMode && (
              <div className="flex items-center gap-1 bg-amber-700 px-2 py-1 rounded-md text-sm">
                <WifiOff className="h-4 w-4" />
                <span>Offline Mode</span>
              </div>
            )}

            {/* Add Cargo Items Button */}
            <button
              onClick={() => setShowAddCargoModal(true)}
              className="px-4 py-2 bg-[#138808] text-white rounded-md hover:bg-[#138808]/90 transition-colors duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              <span>Add Cargo Item</span>
            </button>

            <span className="font-medium">Welcome, {user.name}</span>
            <button
              onClick={() => setShowAccountPage(true)}
              className="h-10 w-10 rounded-full bg-[#138808] flex items-center justify-center text-white hover:bg-[#138808]/90 transition-colors duration-200 shadow-md hover:shadow-lg"
            >
              <span>{user.name.charAt(0)}</span>
            </button>
          </div>
        </div>
      </header>

      <Navigation activeView={activeView} setActiveView={setActiveView} />

      {!isModalOpen && (
        <main className="flex-1 overflow-auto">
          {activeView === "3d-view" && (
            <div className="h-full">
              <Suspense fallback={<CanvasLoader />}>
                <Canvas camera={{ position: [0, 5, 20], fov: 60 }}>
                  <color attach="background" args={["#f5f5f5"]} />
                  <ambientLight intensity={0.5} />
                  <pointLight position={[10, 10, 10]} />
                  <OrbitControls
                    enablePan={true}
                    enableZoom={true}
                    enableRotate={true}
                    minDistance={5}
                    maxDistance={50}
                  />
                  <Environment preset="warehouse" />

                  {containers.map((container, index) => (
                    <StorageContainer
                      key={container.id}
                      position={[index * 4 - containers.length * 2, 0, 0]}
                      container={container}
                      onItemMove={handleItemMove}
                    />
                  ))}

                  {cargoItems
                    .filter((item) => !item.containerId)
                    .map((item, index) => (
                      <CargoItem key={item.id} position={[index * 2 - 2, 3, 3]} item={item} />
                    ))}
                </Canvas>
              </Suspense>
            </div>
          )}

          {activeView === "dashboard" && <Dashboard utilization={utilization} alerts={alerts} />}

          {activeView === "search" && (
            <SearchPanel
              cargoItems={cargoItems}
              containers={containers}
              handleItemRemove={handleItemRemove}
              onAddItem={() => setShowAddCargoModal(true)}
            />
          )}

          {activeView === "waste" && (
            <WasteManagement
              cargoItems={cargoItems}
              containers={containers}
              handleItemMove={handleItemMove}
              handleItemRemove={handleItemRemove}
            />
          )}

          {activeView === "access" && <AccessControl />}

          {activeView === "advisor" && (
            <StorageAdvisor cargoItems={cargoItems} containers={containers} onItemMove={handleItemMove} />
          )}
        </main>
      )}

      {!isModalOpen && <AlertPanel alerts={alerts} />}

      {showAccountPage && (
        <div className="fixed inset-0 bg-[#f5f5f5] z-50 overflow-auto">
          <AccountPage
            onClose={() => setShowAccountPage(false)}
            user={user}
            onLogout={() => {
              logout()
              router.push("/login")
            }}
          />
        </div>
      )}

      {showAddCargoModal && (
        <div className="fixed inset-0 bg-[#f5f5f5] z-50 overflow-auto">
          <AddCargoItem
            onClose={() => setShowAddCargoModal(false)}
            containers={containers}
            onAddSuccess={(newItem) => {
              if (newItem) {
                // If we have a new item, add it directly
                handleAddItem(newItem)
              } else {
                // Otherwise just refresh data
                refreshData()
              }
              setShowAddCargoModal(false)
            }}
          />
        </div>
      )}
    </div>
  )
}

