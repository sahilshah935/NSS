"use client"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/hooks/use-auth"
import type { CargoItem, Container, Alert, UtilizationData, ActivityLog } from "@/types"

export function useCargoData() {
  const { token, user } = useAuth()
  const [cargoItems, setCargoItems] = useState<CargoItem[]>([])
  const [containers, setContainers] = useState<Container[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [utilization, setUtilization] = useState<UtilizationData[]>([])
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isOfflineMode, setIsOfflineMode] = useState(false)

  // Fetch all data
  const fetchData = useCallback(async () => {
    if (!token) return

    setIsLoading(true)
    setError(null)

    try {
      // Try to fetch data from API, but be prepared to fall back to offline mode
      let unitsData: any[] = []
      let itemsData: any[] = []
      let alertsData: any[] = []
      let utilizationData: any[] = []

      try {
        // Fetch storage units (containers)
        const unitsResponse = await fetch("http://localhost:3001/api/storage-units", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (!unitsResponse.ok) {
          console.warn("Failed to fetch storage units, switching to offline mode")
          throw new Error("Failed to fetch storage units")
        }

        unitsData = await unitsResponse.json()

        // Fetch cargo items
        const itemsResponse = await fetch("http://localhost:3001/api/cargo-items", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (!itemsResponse.ok) {
          console.warn("Failed to fetch cargo items, switching to offline mode")
          throw new Error("Failed to fetch cargo items")
        }

        itemsData = await itemsResponse.json()

        // Fetch alerts
        const alertsResponse = await fetch("http://localhost:3001/api/alerts", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (!alertsResponse.ok) {
          console.warn("Failed to fetch alerts, switching to offline mode")
          throw new Error("Failed to fetch alerts")
        }

        alertsData = await alertsResponse.json()

        // Fetch utilization data
        const utilizationResponse = await fetch("http://localhost:3001/api/utilization", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (!utilizationResponse.ok) {
          console.warn("Failed to fetch utilization data, switching to offline mode")
          throw new Error("Failed to fetch utilization data")
        }

        utilizationData = await utilizationResponse.json()

        // If we got here, we successfully fetched all data
        setIsOfflineMode(false)
      } catch (error) {
        console.warn("API connection error, switching to offline mode:", error)
        setIsOfflineMode(true)

        // Generate mock data if we don't have any data yet
        if (cargoItems.length === 0 || containers.length === 0) {
          const mockContainers = generateMockContainers()
          const mockItems = generateMockItems(mockContainers)
          const mockAlerts = generateMockAlerts()
          const mockUtilization = generateMockUtilization(mockContainers)

          setContainers(mockContainers)
          setCargoItems(mockItems)
          setAlerts(mockAlerts)
          setUtilization(mockUtilization)
          setActivityLogs(generateMockActivityLogs())
          setIsLoading(false)
          return
        }
      }

      // If we're not in offline mode, process the fetched data
      if (!isOfflineMode) {
        // Transform to match our Container type
        const transformedContainers: Container[] = unitsData.map((unit: any) => ({
          id: unit.unit_id.toString(),
          name: unit.unit_name,
          capacity: unit.max_capacity,
          section: unit.location_name,
          items: [],
        }))

        // Transform to match our CargoItem type
        const transformedItems: CargoItem[] = itemsData.map((item: any) => ({
          id: item.item_id.toString(),
          name: item.item_name,
          category: item.category_name,
          weight: item.unit_weight,
          expiryDate: item.expiration_date ? new Date(item.expiration_date).toISOString().split("T")[0] : null,
          priority: getPriorityFromCategory(item.category_name),
          containerId: item.stored_in_unit.toString(),
          position: getRandomPosition(),
          quantity: item.quantity,
        }))

        // Update containers with their items
        const containersWithItems = transformedContainers.map((container) => {
          const containerItems = transformedItems.filter((item) => item.containerId === container.id)
          return {
            ...container,
            items: containerItems,
          }
        })

        // Transform to match our Alert type
        const transformedAlerts: Alert[] = alertsData.map((alert: any) => ({
          id: alert.alert_id.toString(),
          title: getAlertTitle(alert.type_name),
          message: alert.message,
          severity: getAlertSeverity(alert.type_name),
          date: new Date(alert.created_at).toISOString().split("T")[0],
        }))

        // Set state with fetched data
        setContainers(containersWithItems)
        setCargoItems(transformedItems)
        setAlerts(transformedAlerts)
        setUtilization(utilizationData)

        // Fetch activity logs
        try {
          const logsResponse = await fetch("http://localhost:3001/api/activity-logs", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          })

          if (logsResponse.ok) {
            const logsData = await logsResponse.json()
            setActivityLogs(logsData)
          } else {
            // Use mock data for activity logs
            setActivityLogs(generateMockActivityLogs())
          }
        } catch (error) {
          // Use mock data for activity logs
          setActivityLogs(generateMockActivityLogs())
        }
      }
    } catch (error) {
      console.error("Error in data fetching process:", error)
      setError(error instanceof Error ? error.message : "An unknown error occurred")

      // Ensure we have some data to display
      if (cargoItems.length === 0 || containers.length === 0) {
        const mockContainers = generateMockContainers()
        const mockItems = generateMockItems(mockContainers)
        const mockAlerts = generateMockAlerts()
        const mockUtilization = generateMockUtilization(mockContainers)

        setContainers(mockContainers)
        setCargoItems(mockItems)
        setAlerts(mockAlerts)
        setUtilization(mockUtilization)
        setActivityLogs(generateMockActivityLogs())
      }

      setIsOfflineMode(true)
    } finally {
      setIsLoading(false)
    }
  }, [token, cargoItems.length, containers.length, isOfflineMode])

  useEffect(() => {
    if (token) {
      fetchData()
    }
  }, [token, fetchData])

  // Log an activity
  const logActivity = useCallback(
    async (
      action: "add" | "move" | "retrieve" | "dispose" | "return" | "rearrange" | "login" | "logout" | "remove",
      targetId: string,
      targetName: string,
      targetType: "item" | "container" | "system",
      details: string,
    ) => {
      if (!token || !user) return

      const newLog: Partial<ActivityLog> = {
        userId: user.id,
        userName: user.name,
        action,
        targetId,
        targetName,
        targetType,
        details,
        timestamp: new Date().toISOString(),
      }

      try {
        // In a real app, this would be sent to the server
        console.log("Logging activity:", newLog)

        // For now, we'll just update the local state
        setActivityLogs((prev) => [
          {
            id: `log-${Date.now()}`,
            ...(newLog as Omit<ActivityLog, "id">),
          },
          ...prev,
        ])
      } catch (error) {
        console.error("Error logging activity:", error)
      }
    },
    [token, user],
  )

  // Handle adding a new item
  const handleAddItem = useCallback(
    (newItem: CargoItem) => {
      // Add the item to the cargoItems array
      setCargoItems((prevItems) => [...prevItems, newItem])

      // Update the container with the new item
      if (newItem.containerId) {
        setContainers((prevContainers) =>
          prevContainers.map((container) => {
            if (container.id === newItem.containerId) {
              return {
                ...container,
                items: [...container.items, newItem],
              }
            }
            return container
          }),
        )
      }

      // Log the activity
      logActivity(
        "add",
        newItem.id,
        newItem.name,
        "item",
        `Added ${newItem.name} to ${newItem.containerId ? containers.find((c) => c.id === newItem.containerId)?.name || "Unknown" : "Unassigned"}`,
      )
    },
    [containers, logActivity],
  )

  // Handle moving items between containers
  const handleItemMove = async (itemId: string, containerId: string | null) => {
    if (!token) return

    try {
      const item = cargoItems.find((i) => i.id === itemId)
      if (!item) return

      const sourceContainer = containers.find((c) => c.id === item.containerId)
      const targetContainer = containers.find((c) => c.id === containerId)

      if (!isOfflineMode) {
        try {
          const response = await fetch(`http://localhost:3001/api/cargo-items/${itemId}/move`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              to_unit: containerId,
              quantity: 1, // Default to moving 1 item
            }),
          })

          if (!response.ok) {
            console.warn("Server returned error, proceeding with local update")
          }
        } catch (error) {
          console.warn("Server connection failed, proceeding with local update")
        }
      }

      // Update local state regardless of server response
      // Update the item's containerId
      const updatedItems = cargoItems.map((i) => (i.id === itemId ? { ...i, containerId } : i))
      setCargoItems(updatedItems)

      // Update containers
      const updatedContainers = containers.map((container) => {
        if (container.id === item.containerId) {
          // Remove item from source container
          return {
            ...container,
            items: container.items.filter((i) => i.id !== itemId),
          }
        } else if (container.id === containerId) {
          // Add item to target container
          const updatedItem = { ...item, containerId }
          return {
            ...container,
            items: [...container.items, updatedItem],
          }
        }
        return container
      })
      setContainers(updatedContainers)

      // Log the activity
      logActivity(
        "move",
        itemId,
        item.name,
        "item",
        `Moved from ${sourceContainer?.name || "unassigned"} to ${targetContainer?.name || "unassigned"}`,
      )
    } catch (error) {
      console.error("Error moving item:", error)
    }
  }

  // Handle removing items
  const handleItemRemove = async (itemId: string) => {
    if (!token) return

    try {
      const item = cargoItems.find((i) => i.id === itemId)
      if (!item) {
        throw new Error("Item not found")
      }

      // Try to call the API if not in offline mode
      if (!isOfflineMode) {
        try {
          // In a real app, this would call an API endpoint to remove the item
          console.log("Removing item via API:", itemId)
        } catch (error) {
          console.warn("Server connection failed, proceeding with local update")
        }
      }

      // Log the activity
      logActivity("remove", itemId, item.name, "item", `Removed ${item.name} from inventory`)

      // Update local state
      setCargoItems(cargoItems.filter((i) => i.id !== itemId))

      // Update containers
      if (item.containerId) {
        setContainers(
          containers.map((container) => {
            if (container.id === item.containerId) {
              return {
                ...container,
                items: container.items.filter((i) => i.id !== itemId),
              }
            }
            return container
          }),
        )
      }

      return true
    } catch (error) {
      console.error("Error removing item:", error)
      return false
    }
  }

  // Get activity logs
  const getActivityLogs = useCallback(() => {
    return activityLogs
  }, [activityLogs])

  // Helper function to determine priority based on category
  const getPriorityFromCategory = (category: string): "high" | "medium" | "low" => {
    switch (category.toLowerCase()) {
      case "medicine":
      case "food":
        return "high"
      case "equipment":
        return "medium"
      default:
        return "low"
    }
  }

  // Helper function to get a random position
  const getRandomPosition = (): "top" | "middle" | "bottom" => {
    const positions: ("top" | "middle" | "bottom")[] = ["top", "middle", "bottom"]
    return positions[Math.floor(Math.random() * positions.length)]
  }

  // Helper function to get alert title from type
  const getAlertTitle = (type: string): string => {
    switch (type) {
      case "low_stock":
        return "Low Stock Alert"
      case "expiration":
        return "Expiration Alert"
      case "system_warning":
        return "System Warning"
      default:
        return "Alert"
    }
  }

  // Helper function to get alert severity from type
  const getAlertSeverity = (type: string): "high" | "medium" | "low" => {
    switch (type) {
      case "low_stock":
        return "medium"
      case "expiration":
        return "high"
      case "system_warning":
        return "low"
      default:
        return "medium"
    }
  }

  // Generate mock containers for offline mode
  const generateMockContainers = (): Container[] => {
    return [
      {
        id: "container-1",
        name: "Storage Bay A",
        capacity: 10,
        section: "Forward",
        items: [],
      },
      {
        id: "container-2",
        name: "Storage Bay B",
        capacity: 8,
        section: "Mid-deck",
        items: [],
      },
      {
        id: "container-3",
        name: "Storage Bay C",
        capacity: 12,
        section: "Aft",
        items: [],
      },
      {
        id: "container-4",
        name: "Science Rack",
        capacity: 6,
        section: "Lab Module",
        items: [],
      },
      {
        id: "container-5",
        name: "Food Storage",
        capacity: 15,
        section: "Galley",
        items: [],
      },
    ]
  }

  // Generate mock items for offline mode
  const generateMockItems = (containers: Container[]): CargoItem[] => {
    const items: CargoItem[] = [
      {
        id: "item-1",
        name: "Medical Supplies",
        category: "Medicine",
        weight: 2.5,
        expiryDate: "2025-06-15",
        priority: "high",
        containerId: "container-4",
        position: "top",
        quantity: 3,
      },
      {
        id: "item-2",
        name: "Food Rations",
        category: "Food",
        weight: 5,
        expiryDate: "2024-12-10",
        priority: "high",
        containerId: "container-5",
        position: "middle",
        quantity: 10,
      },
      {
        id: "item-3",
        name: "Experiment Equipment",
        category: "Equipment",
        weight: 8,
        expiryDate: null,
        priority: "medium",
        containerId: "container-4",
        position: "bottom",
        quantity: 2,
      },
      {
        id: "item-4",
        name: "Water Containers",
        category: "Supplies",
        weight: 10,
        expiryDate: null,
        priority: "high",
        containerId: "container-1",
        position: "bottom",
        quantity: 5,
      },
      {
        id: "item-5",
        name: "Spare Parts",
        category: "Equipment",
        weight: 15,
        expiryDate: null,
        priority: "medium",
        containerId: "container-3",
        position: "middle",
        quantity: 8,
      },
      {
        id: "item-6",
        name: "Personal Items",
        category: "Supplies",
        weight: 1,
        expiryDate: null,
        priority: "low",
        containerId: "container-2",
        position: "top",
        quantity: 4,
      },
      {
        id: "item-7",
        name: "Vitamins",
        category: "Medicine",
        weight: 0.5,
        expiryDate: "2024-08-20",
        priority: "high",
        containerId: "container-5",
        position: "top",
        quantity: 2,
      },
      {
        id: "item-8",
        name: "Research Samples",
        category: "Science",
        weight: 1.2,
        expiryDate: "2024-05-30",
        priority: "medium",
        containerId: "container-4",
        position: "middle",
        quantity: 6,
      },
      {
        id: "item-9",
        name: "Cleaning Supplies",
        category: "Supplies",
        weight: 3,
        expiryDate: null,
        priority: "low",
        containerId: "container-1",
        position: "middle",
        quantity: 3,
      },
      {
        id: "item-10",
        name: "Emergency Kit",
        category: "Equipment",
        weight: 4,
        expiryDate: null,
        priority: "high",
        containerId: "container-3",
        position: "top",
        quantity: 1,
      },
    ]

    // Update container items
    containers.forEach((container) => {
      container.items = items.filter((item) => item.containerId === container.id)
    })

    return items
  }

  // Generate mock alerts for offline mode
  const generateMockAlerts = (): Alert[] => {
    return [
      {
        id: "alert-1",
        title: "Low Stock Alert",
        message: "Medical supplies running low. Resupply needed within 30 days.",
        severity: "medium",
        date: new Date().toISOString().split("T")[0],
      },
      {
        id: "alert-2",
        title: "Expiration Alert",
        message: "Research samples will expire in 7 days. Please prioritize usage.",
        severity: "high",
        date: new Date().toISOString().split("T")[0],
      },
      {
        id: "alert-3",
        title: "System Warning",
        message: "Storage Bay C temperature fluctuation detected. Monitoring required.",
        severity: "low",
        date: new Date(Date.now() - 86400000).toISOString().split("T")[0],
      },
    ]
  }

  // Generate mock utilization data for offline mode
  const generateMockUtilization = (containers: Container[]): UtilizationData[] => {
    return containers.map((container) => ({
      name: container.name,
      current: container.items.length,
      capacity: container.capacity,
    }))
  }

  // Generate mock activity logs
  const generateMockActivityLogs = (): ActivityLog[] => {
    return [
      {
        id: "log-1",
        userId: 1,
        userName: "Rakesh Sharma",
        action: "move",
        targetId: "item-1",
        targetName: "Medical Supplies",
        targetType: "item",
        details: "Moved from Storage Bay A to Science Rack",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: "log-2",
        userId: 2,
        userName: "Kalpana Chawla",
        action: "add",
        targetId: "item-2",
        targetName: "Food Rations",
        targetType: "item",
        details: "Added 5 units to Food Storage",
        timestamp: new Date(Date.now() - 7200000).toISOString(),
      },
      {
        id: "log-3",
        userId: 3,
        userName: "Sunita Williams",
        action: "dispose",
        targetId: "item-3",
        targetName: "Expired Medication",
        targetType: "item",
        details: "Moved to Waste Container",
        timestamp: new Date(Date.now() - 10800000).toISOString(),
      },
    ]
  }

  return {
    cargoItems,
    containers,
    alerts,
    utilization,
    activityLogs,
    handleItemMove,
    handleItemRemove,
    handleAddItem,
    logActivity,
    getActivityLogs,
    isLoading,
    error,
    refreshData: fetchData,
    isOfflineMode,
  }
}

