"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: number
  name: string
  email: string
  role: string
}

interface AuthContextType {
  user: User | null
  token: string | null
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  loginWithDemo: () => void
  logout: () => void
  isLoading: boolean
  error: string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check for token in localStorage
    const storedToken = localStorage.getItem("token")
    if (storedToken) {
      setToken(storedToken)
      fetchUser(storedToken)
    } else {
      setIsLoading(false)
    }
  }, [])

  const fetchUser = async (authToken: string) => {
    try {
      const response = await fetch("http://localhost:3001/api/users/me", {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      } else {
        // Token is invalid or expired
        localStorage.removeItem("token")
        setToken(null)
      }
    } catch (error) {
      console.error("Error fetching user:", error)

      // If we can't connect to the server, create a demo user
      const demoUser = {
        id: 1,
        name: "Rakesh Sharma",
        email: "admin@example.com",
        role: "admin",
      }
      setUser(demoUser)
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    setError(null)

    try {
      // Try to login with the API
      try {
        const response = await fetch("http://localhost:3001/api/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email, password }),
        })

        const data = await response.json()

        if (response.ok) {
          localStorage.setItem("token", data.token)
          setToken(data.token)
          setUser(data.user)
          return
        } else {
          console.warn("API login failed, using demo login:", data.error)
        }
      } catch (error) {
        console.warn("API connection failed, using demo login")
      }

      // If API login fails, use demo login
      if (email === "admin@example.com" && password === "admin123") {
        loginWithDemo()
      } else {
        throw new Error("Invalid credentials")
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : "An unknown error occurred")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const register = async (name: string, email: string, password: string) => {
    setIsLoading(true)
    setError(null)

    try {
      // Try to register with the API
      try {
        const response = await fetch("http://localhost:3001/api/auth/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name, email, password }),
        })

        const data = await response.json()

        if (response.ok) {
          // Registration successful, now login
          return login(email, password)
        } else {
          console.warn("API registration failed:", data.error)

          // If the error is that the user already exists, we can try to login
          if (data.error && data.error.includes("already exists")) {
            return login(email, password)
          }

          throw new Error(data.error || "Registration failed")
        }
      } catch (error) {
        console.warn("API connection failed, using demo registration")
      }

      // If API registration fails, create a demo user
      // For demo purposes, we'll just create a user with the provided details
      const demoUser = {
        id: Date.now(),
        name,
        email,
        role: "user",
      }

      const demoToken = "demo_token_" + Date.now()
      localStorage.setItem("token", demoToken)
      setToken(demoToken)
      setUser(demoUser)
    } catch (error) {
      setError(error instanceof Error ? error.message : "An unknown error occurred")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithDemo = () => {
    // Create a demo token
    const demoToken = "demo_token_" + Date.now()
    localStorage.setItem("token", demoToken)
    setToken(demoToken)

    // Create a demo user
    const demoUser = {
      id: 1,
      name: "Rakesh Sharma",
      email: "admin@example.com",
      role: "admin",
    }
    setUser(demoUser)
  }

  const logout = () => {
    localStorage.removeItem("token")
    setToken(null)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, token, login, register, loginWithDemo, logout, isLoading, error }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

